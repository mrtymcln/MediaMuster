#pragma once

#include <QString>
#include <QStringList>
#include <QMetaType>
#include <QVector>
#include <QtGlobal>

#include <optional>

// Requests contain only the file facts execution and journal replay need.
// Keeping them separate from MediaFile lets recovery work without a scan or UI.

// MARK: - OpKind

/// Supported operations. New Undo jobs require authorization from the caller;
/// the application supplies it according to FeatureFlags::kUndo.
/// Rename is Rebalance's same-filesystem relocation.
enum class OpKind : int
{
	Copy = 0,
	Move = 1,
	Delete = 2,
	Rename = 3,
	Undo = 4
};

// MARK: - ConflictPolicy

/// Destination conflicts never permit replacement. KeepBoth chooses a free
/// name; Skip leaves the source alone. An unexpected occupied destination with
/// no KeepBoth policy fails the item, preserving its source.
enum class ConflictPolicy : int
{
	KeepBoth = 0,
	Skip = 1
};

// MARK: - On-disk names
//
// Journal names are explicit. Changes require a new schema; unsupported
// schemas are rejected.
inline QString opKindName(OpKind k)
{
	switch (k)
	{
	case OpKind::Copy:
		return QStringLiteral("copy");
	case OpKind::Move:
		return QStringLiteral("move");
	case OpKind::Delete:
		return QStringLiteral("delete");
	case OpKind::Rename:
		return QStringLiteral("rename");
	case OpKind::Undo:
		return QStringLiteral("undo");
	}
	return QStringLiteral("copy");
}

/// nullopt for a name this build doesn't know. Callers must treat an
/// unknown kind as "do not touch": a wrong guess here is how a recovery
/// pass turns a crash into data loss.
inline std::optional<OpKind> opKindFromName(const QString &s)
{
	if (s == QStringLiteral("copy"))
		return OpKind::Copy;
	if (s == QStringLiteral("move"))
		return OpKind::Move;
	if (s == QStringLiteral("delete"))
		return OpKind::Delete;
	if (s == QStringLiteral("rename"))
		return OpKind::Rename;
	if (s == QStringLiteral("undo"))
		return OpKind::Undo;
	return std::nullopt;
}

inline QString conflictPolicyName(ConflictPolicy policy)
{
	switch (policy)
	{
	case ConflictPolicy::KeepBoth:
		return QStringLiteral("keepboth");
	case ConflictPolicy::Skip:
		return QStringLiteral("skip");
	}
	return {};
}

inline std::optional<ConflictPolicy> conflictPolicyFromName(const QString &name)
{
	if (name == QStringLiteral("keepboth"))
		return ConflictPolicy::KeepBoth;
	if (name == QStringLiteral("skip"))
		return ConflictPolicy::Skip;
	return std::nullopt;
}

// MARK: - OpItem

/// Header identities established during scanning. Database-only associations
/// remain in the scan claims; they are not requirements imposed on the header.
struct OpHeaderIdentity
{
	QString mobId;
	QStringList masterMobIds;
	QString unavailableReason; ///< A changed or contradictory header cannot authorize an operation.
};

/// One selected file, persisted in the journal so a job can resume without
/// a rescan. Size, time and Avid IDs are scan claims, not fresh disk evidence.
/// The runner checks filesystem identity and supplied size/time before acting;
/// applicable MXF/legacy IDs also receive a header cross-check through the open handle.
struct OpItem
{
	QString src;			 ///< Absolute source path; the item's identity key.
	QString name;			 ///< Destination leaf name (usually the source's).
	QString mediaFolderName; ///< Source folder name, reused when preserving MXF structure.
	/// OMF-era: the scanner's verdict (MediaFile::omfEra). Preserve mode
	/// sends a legacy file to <dest>/OMFI MediaFiles/ whatever `mediaFolderName`
	/// says; journaled so a resumed run lands it in the same place.
	bool omfEra = false;
	qint64 bytes = 0;
	qint64 modifiedMs = -1;	  ///< Scanner timestamp; -1 when not supplied.
	bool maintenance = false; ///< Rebalance database relocation, excluded from media totals.
	QString policy;			  ///< Conflict policy by name; empty = none chosen.

	// Scan claims about the media inside the file (empty when unknown).
	QString mobId;			  ///< Avid MOB ID of this essence file.
	QString masterMobId;	  ///< The master clip's MOB ID.
	QString clipName;		  ///< The human name the editor knows the clip by.
	QStringList masterMobIds; ///< Every established association, including database observations.
	QString scanPath;
	QString scanVolumeIdentifier;					///< VolumeIdentity identifier, distinct from native expectedVolumeId.
	std::optional<OpHeaderIdentity> headerIdentity; ///< Absent in older requests/journals.
	/// PMR/MDB file identity to verify when the scan deliberately skipped its header.
	/// Kept separate from header-established IDs and database-only master associations.
	QString databaseMobIdToVerify;

	// Inverse operations must target the object recorded by the original job,
	// not whichever file happens to occupy its path while building the new plan.
	QString expectedFileId;
	QString expectedVolumeId;
	qint64 expectedModified = 0;
	QString undoAction;
	int undoEntryId = -1;
	QString trashReceipt;

	QString renameDst; ///< Full destination for Rebalance relocation or Undo restoration.
	QString groupKey;  ///< Relatives cancel boundary: cancel only
					   ///< lands between groups, never inside one.
};

// MARK: - OpRequest

/// Complete execution input, assembled from UI choices, a rebalance plan,
/// or a saved journal.
struct OpRequest
{
	OpKind kind = OpKind::Copy;
	QString destRoot;			 ///< Copy/Move destination root; empty for Delete/Rename/Undo.
	bool preserve = false;		 ///< Recreate the MXF folder path or flat OMFI root under destRoot.
	bool copyThenRemove = false; ///< Whole Move uses copy-then-remove, including mixed volumes.
	bool undoEnabled = false;	 ///< Runtime permission to start a NEW Undo; not persisted.
	QVector<OpItem> items;

	QString resumeJournalPath;	 ///< Continue this journal; never retire it on dispatch.
	QString restoreJournalPath;	 ///< Restore retained originals only, including dismissed jobs.
	QString diagnosticTrashRoot; ///< Explicit disposable-test root; production leaves empty.
	QString undoJournalPath;	 ///< Forward job requested by a new Undo command.
	QString undoOf;				 ///< Persisted forward-job link for an executing inverse operation.
};

// Files confirmed unchanged after the native bin refused them. The worker
// revalidates each original again after the GUI's answer, before relocation.
struct OpTrashFallbackItem
{
	QString source;
	QString destination;
	QString reason;
};

// Explicit outcomes keep a retained source visible in the media table.
struct OpResult
{
	enum class State
	{
		Completed,
		NoEffect,
		SourceRetained,
		OriginalRestored,
		Skipped,
		Cancelled,
		Failed,
		NeedsAttention
	};
	State state = State::Failed;
	QString name;
	QString source;
	QString destination;
	QString message;
	bool sourceRemoved = false;
	QString restoredOriginalPath; ///< Confirmed return by Undo or original restoration; empty otherwise.
};
Q_DECLARE_METATYPE(OpResult)
