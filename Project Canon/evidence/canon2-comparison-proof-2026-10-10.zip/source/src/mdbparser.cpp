#include "mdbparser.h"
#include "avidusage.h"
#include "bentofile.h"
#include "diagnostics.h"
#include "omfobjects.h"
#include "omfuid.h"

#include <QByteArrayView>
#include <QFile>
#include <QSet>
#include <QVector>

// Reads msmMMOB.mdb through its Bento table of contents.
//
// MARK: - What the database is
//
// `msmMMOB.mdb` is an OMF Interchange object store (Avid's pre-AAF
// format; the spec is public) inside an Apple Bento container (BentoFile).
// The captured Avid databases use legacy MOBJ objects with a 32-byte
// OMFI:MOBJ:MobID — the same UMID the PMR and the MXF carry, in Avid's byte
// order (PMR↔MDB join raw; MXF needs MobId::swapMaterialByteOrder). Standard OMF2 instead
// uses explicit MMOB/SMOB/CMOB classes, mob slots and MediaDescription. Both
// schemas are handled independently of Bento container revision. Properties are named
// by a dictionary the file itself embeds, so this parser resolves
// "OMFI:CPNT:Name" per file and hard-codes no ids.
//
// The objects worth reading, and where their facts live:
//
//   master mob   (no PhysicalMedia; UsageCode 7, or 1 for a precompute)
//     OMFI:CPNT:Name                 the clip name Avid displays
//     OMFI:CPNT:Attributes → ATTR → OMFI:ATTR:AttrRefs → ATTB list, each
//        OMFI:ATTB:Name + OMFI:ATTB:Kind (1 int, 2 string, 3 object, 4 bob):
//          _ORG_BIN       (3) → MCBR → OMFI:MCBR:MC:binNameUTF8 (else MC:binName)
//          _IMPORTSETTING (3) → ATTR → nested _SRCFILE (3) → MACL →
//                               OMFI:FL:POSIXPathName (else PathNameUTF8, PathName)
//          _USER          (3) → ATTR → `Video` (2) = container ("QTFF"),
//                               `UNC Path` (2) = the same path again
//   file mob     (OMFI:MOBJ:PhysicalMedia → a media descriptor; UsageCode 0,
//                 or 9 for a precompute)
//     OMFI:CPNT:EditRate             the clip's frame rate (audio duration maths)
//     descriptor class               CDCI/MPGI/RGBA/JPED video, PCMA/MPGA/WAVE audio
//     OMFI:DIDD:EssenceCompression   the 16-byte codec label — in AAF AUID byte
//                                    order (see auidToUl); or, on legacy DNxHD,
//     OMFI:DIDD:DIDResolutionID      Avid's numeric resolution id (see ulFromResId)
//     OMFI:DIDD:StoredWidth/Height   + OMFI:DIDD:FrameLayout (u16): the MDB stores
//                                    a HALF height for layouts 1 AND 3 (the MXF only
//                                    for 1) — normalised here, flagged for finalise
//     OMFI:MDFL:SampleRate           rational; decimal approximations (2997/100),
//                                    so it goes through MediaMetadataUtil::applyEditRate
//     OMFI:MDFL:Length               frames (video) / samples (audio)
//     OMFI:CDCI:ComponentWidth / OMFI:MDAU:BitsPerSample / OMFI:MDAU:NumChannels
//     OMFI:TRKG:Tracks → TRAK → TrackComponent → SEQU/SCLP/TCCP: drop frame
//                                    from OMFI:TCCP:Flags, reached through the
//                                    source mobs a SCLP points at
//   source mob   (PhysicalMedia → MDES; the import/tape source)
//                 supplies linked timecode and a fallback project name.
//
// MPEG audio (MPGA) has no codec label in the observed MDBs. Mark it
// essenceComplete=false so the scanner reads the media header instead.
//
// OmfObjects shares the attribute, descriptor and timecode walks with the
// OMF media reader. This parser loads and groups database records by MobID.
//
// In the OMF-era fixtures, msmMMOB.mdb uses 12-byte omfi:UIDs; MC 2026
// also writes a 32-byte UMID on the physical mob. Both widths are keyed
// through OmfUid::toIdText. Legacy audio uses WAVD/AIFD descriptors,
// and picture codecs use a 4CC plus resolution id. _PJ on the file or
// source mob supplies the project when the PMR field is empty, as in the
// shipped SupportingFiles fixtures. Version-2 PMRs can store projects;
// version 1 omits them. A physical mob owning an MDES is a source mob.
//
// Parsing rules:
//  - Codec labels use GUID order; auidToUl converts them to MXF byte order.
//  - Property names are dictionary entries; values are reached through the TOC.
//  - Multiple objects may share a MobID. Merge their first non-empty fields
//    so a clip's name and bin can come from different objects.

namespace
{
	/// Avid's placeholder MOB — byte-identical across unrelated projects, in no
	/// MXF. Never a real clip; skipped on sight.
	const QByteArray &placeholderMobId()
	{
		static const QByteArray kMob =
			QByteArray::fromHex("060a2b340101010001010f0013000000bacc8a260647d528e5cd3f5b5f40443f");
		return kMob;
	}

} // namespace

// MARK: - Load

MdbDatabase MdbParser::load(const QString &mdbFilePath, bool *ok)
{
	if (ok)
		*ok = false;
	MdbDatabase db;

	QFile file(mdbFilePath);
	if (!file.open(QIODevice::ReadOnly))
	{
		qCWarning(lcMdb) << "cannot open" << mdbFilePath << file.errorString();
		return db;
	}
	const QByteArray data = file.readAll();
	if (file.error() != QFileDevice::NoError)
	{
		qCWarning(lcMdb) << "cannot read" << mdbFilePath << file.errorString();
		return db;
	}
	file.close();

	BentoFile b;
	QString why;
	if (!b.load(data, &why))
	{
		qCWarning(lcMdb) << mdbFilePath << "is not a readable Avid MDB:" << why;
		return db;
	}
	if (ok)
		*ok = true;

	const OmfObjects::PropertyIds p(b);
	db.revision = p.revision;
	if (p.mobId < 0)
	{
		qCDebug(lcMdb) << mdbFilePath << "carries no MobID property — an empty database";
		return db;
	}

	// Group Mob objects by their MobId. Avid writes the same MobID on
	// more than one object, so each clip is the union of its objects.
	OmfObjects::ObjectIdByMobId objectByMob; ///< First object per MobID (for SCLP hops).
	QHash<QString, QVector<quint32>> objectsByMobId;
	QVector<QString> order;
	for (quint32 obj : b.objectsWithProperty(p.mobId))
	{
		if (!OmfObjects::isMobClass(b.objectClass(obj)))
			continue;
		const QByteArray raw = OmfObjects::normalizedMobId(b, b.bytes(obj, p.mobId));
		// Canonical keys support 12-byte OMF IDs and 32-byte UMIDs.
		const QString mobId = OmfUid::toIdText(raw);
		if (mobId.isEmpty() || raw == QByteArrayView(placeholderMobId()))
			continue;
		if (!objectByMob.contains(raw))
			objectByMob.insert(raw, obj);
		auto it = objectsByMobId.find(mobId);
		if (it == objectsByMobId.end())
		{
			it = objectsByMobId.insert(mobId, {});
			order.append(mobId);
		}
		it->append(obj);
	}

	int completeFileCount = 0;
	for (const QString &mobId : order)
	{
		const QVector<quint32> &objs = objectsByMobId[mobId];

		// A file mob owns a media descriptor; a source mob owns an MDES;
		// a master mob has no physical-media descriptor.
		quint32 fileMobObjectId = 0, mediaDescriptorObjectId = 0;
		bool anyPhysical = false;
		bool explicitMaster = false;
		bool legacyMaster = false;
		qint32 usageCode = AvidUsage::kMissing;
		for (quint32 obj : objs)
		{
			explicitMaster |= b.objectClass(obj) == "MMOB";
			const auto usage = b.read(obj, p.usage);
			if (usage.status != BentoFile::ReadStatus::Missing)
			{
				const qint32 code = usage.ok() && usage.data.size() == 4 ? AvidUsage::integerCode(b.uintValue(usage.data)) : AvidUsage::kInvalidOrConflicting;
				legacyMaster |= AvidUsage::isMasterCode(code);
				usageCode = AvidUsage::merge(usageCode, code);
			}
			anyPhysical |= b.hasProperty(obj, p.physMedia);
			const quint32 desc = b.readObjectId(obj, p.physMedia);
			if (desc == 0)
				continue;
			anyPhysical = true;
			if (fileMobObjectId == 0 && OmfObjects::isMediaClass(b.objectClass(desc)))
			{
				fileMobObjectId = obj;
				mediaDescriptorObjectId = desc;
			}
		}

		if (fileMobObjectId != 0)
		{
			MdbFileMob f;
			f.essence.fileMobId = mobId;
			f.usageCode = usageCode;
			// Skipping the header requires usable technical facts, not just a
			// recognised descriptor class with missing/unreadable properties.
			bool codecKnown = false;
			if (OmfObjects::readDescriptor(b, p, fileMobObjectId, mediaDescriptorObjectId, objectByMob, f.essence, &codecKnown))
			{
				const auto length = b.read(mediaDescriptorObjectId, p.length);
				f.essenceComplete =
					f.essence.valid && codecKnown && length.ok() && (length.data.size() == 4 || length.data.size() == 8) &&
					b.int64Value(length.data) >= 0 &&
					(f.essence.isAudio ? f.essence.sampleRate > 0 && f.essence.channels > 0 && !f.essence.bitDepth.isEmpty()
									   : !f.essence.frameRate.isEmpty());
			}
			if (f.essenceComplete)
				++completeFileCount;

			// OMF-era: the project lives on the file mob (MC 2026) or on the
			// source mob its SCLP names (the 2021 slates); the file mob wins.
			// An MXF-era file mob carries neither, so this reads empty there.
			{
				OmfObjects::Attributes a;
				a.omfEra = b.value(fileMobObjectId, p.mobId).size() == OmfUid::kUidSize; // OMF-era: 12-byte mob
				QSet<quint32> seen;
				for (quint32 obj : objs)
					OmfObjects::walkAttributes(b, p, b.readObjectId(obj, p.attrs), a, seen);
				if (a.project.isEmpty())
				{
					const quint32 src = OmfObjects::findUniqueReferencedMobObjectId(b, p, fileMobObjectId, objectByMob);
					const QString sourceMobId = OmfUid::toIdText(OmfObjects::normalizedMobId(b, b.bytes(src, p.mobId)));
					const auto sourceObjects = objectsByMobId.constFind(sourceMobId);
					if (sourceObjects != objectsByMobId.cend())
						for (quint32 obj : *sourceObjects)
							OmfObjects::walkAttributes(b, p, b.readObjectId(obj, p.attrs), a, seen);
				}
				f.project = a.project;
			}

			// OMF-era: the descriptor's locator list may name the volume the
			// file was last seen on (MSML). Diagnostic only — never a fact.
			for (quint32 loc : b.readObjectIds(mediaDescriptorObjectId, p.locator))
			{
				if (b.objectClass(loc) != "MSML")
					continue;
				QString volume = BentoFile::utf8String(b.value(loc, p.lastKnownVolumeUtf8));
				if (volume.isEmpty())
					volume = BentoFile::string(b.value(loc, p.lastKnownVolume));
				if (!volume.isEmpty())
					qCDebug(lcMdb) << mobId << "last known volume" << volume;
			}
			db.files.insert(mobId, f);
			continue;
		}
		if (anyPhysical || (p.omf2 && !explicitMaster) ||
			(p.revision == OmfObjects::Revision::Omf1 && !legacyMaster))
			continue; // No eligible master: descriptor-bearing or excluded by the schema rules.

		MdbMasterMob m;
		m.usageCode = usageCode;
		OmfObjects::Attributes a;
		// OMF mobs allow WINL/UNXL source locators; MXF-era mobs use MACL only.
		a.omfEra = b.value(objs.first(), p.mobId).size() == OmfUid::kUidSize;
		QSet<quint32> seen;
		for (quint32 obj : objs)
		{
			if (m.clipName.isEmpty())
				m.clipName = BentoFile::string(b.value(obj, p.name));
			OmfObjects::walkAttributes(b, p, b.readObjectId(obj, p.attrs), a, seen);
		}
		m.bin = a.bin;
		m.classificationKnown = AvidUsage::isMasterCode(m.usageCode);
		if (AvidUsage::masterClassification(m.usageCode) == AvidUsage::Classification::Precompute)
			m.precomputeCategory = OmfObjects::precomputeCategory(b, p, objs);
		m.sourceFilePath = a.sourceFilePath;
		m.sourceContainer = a.sourceContainer;
		m.project = a.project; // OMF-era: _PJ on a master mob, when a file keeps it there.
		m.isImported = a.isImported;
		if (!m.sourceFilePath.isEmpty())
			m.sourceFileName = MediaMetadataUtil::sourceFileBaseName(m.sourceFilePath);
		db.masters.insert(mobId, m);
	}

	// Reverse the master -> source-clip -> file link. A file referenced by
	// two distinct masters has no unique answer; never choose hash order.
	QHash<QString, QSet<QString>> masterMobIdsByFileMobId;
	for (auto master = db.masters.cbegin(); master != db.masters.cend(); ++master)
		for (quint32 obj : objectsByMobId.value(master.key()))
			for (quint32 target : OmfObjects::referencedMobObjectIds(b, p, obj, objectByMob))
			{
				const QString fileMobId = OmfUid::toIdText(OmfObjects::normalizedMobId(b, b.bytes(target, p.mobId)));
				if (db.files.contains(fileMobId))
					masterMobIdsByFileMobId[fileMobId].insert(master.key());
			}
	for (auto file = db.files.begin(); file != db.files.end(); ++file)
	{
		const auto masters = masterMobIdsByFileMobId.value(file.key());
		file->masterMobIds = masters.values();
		file->masterMobIds.sort();
		if (masters.size() == 1)
			file->masterMobId = *masters.cbegin();
	}

	qCDebug(lcMdb) << mdbFilePath << ":" << b.entryCount() << "TOC entries," << db.masters.size() << "clips,"
				   << db.files.size() << "files (" << completeFileCount << "complete )";
	return db;
}
