#pragma once

#include "managemediadialog.h"
#include "mediafile.h"
#include "mediafilterproxy.h"
#include "mediascanner.h"
#include "mediatablemodel.h"
#include "fileoperationcontroller.h"
#include "volumelistwidget.h"
#include "volumemanager.h"

#include <QElapsedTimer>
#include <QItemSelection>
#include <QListWidget>
#include <QMainWindow>
#include <QSet>
#include <functional>

class QLabel;
class QLayout;
class QLineEdit;
class QPlainTextEdit;
class QPushButton;
class QSplitter;
class QStatusBar;
class QTabBar;
class QTableView;
class QTimer;

// MARK: - MainWindow

/// Composes volume discovery, scanning and operation controllers with
/// MediaTableModel + MediaFilterProxy, and on-demand dialogs.
/// Owns window widgets, selection and presentation of the current media set.
class MainWindow : public QMainWindow
{
	Q_OBJECT
	friend class TestOperationUi;

public:
	/// UiOnly supports interface tests/previews without volume discovery,
	/// monitoring, crash collection or journal recovery against the host.
	enum class StartupMode
	{
		Normal,
		UiOnly
	};
	explicit MainWindow(QWidget *parent = nullptr, StartupMode startup = StartupMode::Normal);
	~MainWindow();

private slots:

	// MARK: - User actions

	void refreshVolumes();
	void scanSelected();
	void scanEverything();
	void onScanDiscovering(const QString &path);
	void onScanProgress(int current, int total, const QString &currentPath);
	void onScanLogBatch(const QVector<LogMessage> &batch);
	void onScanFinished(const QVector<MediaFile> &results);
	void onScanFailed(const QString &message);
	void onFilterChanged(int index);
	void onSearchChanged(const QString &text);
	void onSelectionChanged();
	void onFileOperations();
	void onExportCsv();
	void onRevealInFinder();
	void onSelectRelatives();
	void onInvertSelection();
	void autoFitColumns();
	void onTableDoubleClicked(const QModelIndex &index);
	void onPathsDropped(const QStringList &paths);
	void onCheckPermissions();
	void onFilterByBins();
	void onFilterPrecomputes();
	void onRebalance();
	void onAbout();
	void showMediaMusterTrashDialog(const QString &trashFolderPath, int fileCount);
	void showTableContextMenu(const QPoint &pos);

private:
	// MARK: - Setup

	void setupUi();
	void buildSidePanel();
	QWidget *buildToolbar();
	void buildTable();
	void setMonospaceTableEnabled(bool enabled);
	void buildConsole();
	void buildStatusBar();

	void setupMenus();
	void buildFileMenu();
	void buildEditMenu();
	void buildViewMenu();
	void buildSpecialMenu();
	void buildDebugMenu();
	void buildHelpMenu();

	void setupConnections();
	void startScanWithPaths(const QStringList &paths);
	void addLog(QtMsgType level, const QString &module, const QString &message);

	/// Adapt the selected media rows to the controller's request format.
	bool dispatchOperation(OpKind kind, QVector<MediaFile> files,
						   const QString &dest, bool preserve,
						   const QHash<QString, ConflictPolicy> &policies);

	/// Collects MacOS crash reports into the logs folder,
	/// and nudges the user to send them to the developer.
	void collectCrashReports();

	// MARK: - Status bar

	void updateStatusBar();
	void doUpdateStatusBar();

	void doUpdateSelectionBytes();

	void updateFilterCounts();
	void openManageMedia(ManageMediaDialog::Operation initialOp);
	void updateActivityUi();
	void updateSelectionActions();
	class ProgressDialog *progressDialog();
	/// Only visible selected rows become operation/export inputs. Remembered
	/// hidden selections are restored to the view when filters permit them.
	QVector<MediaFile> selectedFiles() const;
	void addVolumePath(const QString &path);

	/// Apply the same presentation to detected volumes and manual folders.
	/// displayName includes any suffix needed to distinguish duplicate names.
	class QListWidgetItem *makeVolumeItem(const VolumeInfo &v, const QString &displayName);

	/// Map visible rows back to the inventory before reading their metadata.
	const MediaFile &fileForProxyIndex(const QModelIndex &proxyIndex) const;
	const MediaFile &fileAtProxyRow(int proxyRow) const;

	/// Coalesce ascending visible rows into ranges to reduce selection signals.
	QItemSelection selectionForRows(const QVector<int> &proxyRows) const;

	/// Sum of sizeBytes over the inclusive proxy-row range [first, last].
	/// An empty range (last < first) sums to 0. Backs both the table total
	/// and the per-selection total in the status bar.
	qint64 sumBytesInProxyRange(int first, int last) const;

	// MARK: - Selection persistence

	/// Wrap a proxy filter mutation so the user's selection survives
	/// the row-visibility shuffle. The proxy drops hidden rows from
	/// the selection model when filtered out; this helper re-applies
	/// the persistent path set after the mutation runs.
	void applyFilterPreservingSelection(const std::function<void()> &mutation);

	/// Keeps manually-added paths when detected volumes change.
	void rebuildVolumeList(const QVector<VolumeInfo> &volumes);

	void addFilterChip(QLayout *layout, const QString &text, std::function<void()> onClose);
	QString precomputeSelectionLabel(const PrecomputeFilter &filter) const;
	QString precomputeVolumeLabel(const QString &volumePath) const;
	void rebuildFilterChips();
	/// Refresh dependent views after the inventory changes; does not scan disk.
	void refreshEverything();
	void rebuildProjectList();
	void setOmfScanEnabled(bool enabled);
	void setPrecomputesEnabled(bool enabled);
	void setClipDurationEnabled(bool enabled);

	/// Drop every active filter back to its default after a scan swaps in a
	/// new dataset, so a stale predicate (a project name or bin MOB from the
	/// previous scan) can't hide the fresh results.
	void resetFiltersForNewScan();

	// MARK: - Owned services

	VolumeManager *m_volumeManager;
	MediaScanner *m_scanner;
	FileOperationController *m_operations;

	MediaTableModel *m_model;
	MediaFilterProxy *m_proxy;

	// MARK: - Widgets

	QSplitter *m_mainSplitter;
	QWidget *m_sidePanel;
	VolumeListWidget *m_volumeList;
	QPushButton *m_scanButton;
	QPushButton *m_scanAllButton;
	QListWidget *m_projectList;
	QTabBar *m_filterTabs;
	QWidget *m_chipsBar = nullptr; ///< Hidden when no filters are active.
	QLineEdit *m_searchField;
	QTableView *m_tableView;
	QPlainTextEdit *m_console;
	QSplitter *m_contentSplitter;

	class ProgressDialog *m_progressDialog = nullptr;

	QPushButton *m_manageMediaButton;
	QPushButton *m_binFilterButton;
	QPushButton *m_precomputeFilterButton = nullptr;
	QPushButton *m_exportCsvButton;
	QPushButton *m_rebalanceButton;

	// Shared commands keep menu and button availability in sync.
	class QAction *m_addFolderAction = nullptr;
	class QAction *m_refreshVolumesAction = nullptr;
	class QAction *m_scanSelectedAction = nullptr;
	class QAction *m_scanAllAction = nullptr;
	class QAction *m_manageMediaAction = nullptr;
	class QAction *m_binFilterAction = nullptr;
	class QAction *m_rebalanceAction = nullptr;
	class QAction *m_exportAction = nullptr;
	class QAction *m_revealAction = nullptr;
	class QAction *m_selectRelativesAction = nullptr;
	class QAction *m_selectInverseAction = nullptr;
	bool m_exportInProgress = false;
	bool m_selectionHasMasterMob = false;

	// MARK: - Status-bar labels

	QLabel *m_statusFiles;
	QLabel *m_statusSelected;
	QLabel *m_statusSize;
	QLabel *m_statusSelSize;
	QLabel *m_statusScanTime;
	QLabel *m_statusSep1;
	QLabel *m_statusSep2;

	// MARK: - Scan state

	QElapsedTimer m_scanTimer;
	bool m_showAllFilterTabs = false;
	bool m_omfScanEnabled = false;
	bool m_precomputesEnabled = false;
	class QAction *m_precomputeFilterAction = nullptr;
	QSet<QString> m_manualVolumes;

	// MARK: - Selection persistence

	/// File paths of every row the user has selected, tracked across
	/// filter changes. The selection model itself drops hidden rows
	/// when a filter excludes them; this set survives.
	QSet<QString> m_persistentSelectedPaths;

	/// Guards `onSelectionChanged` while `applyFilterPreservingSelection`
	/// shuffles rows; without this the rows the proxy drops would
	/// shrink the persistent record and lose the user's picks.
	bool m_inFilterRestore = false;

	class BinFilterDialog *m_binFilterDialog = nullptr;

	/// Cached so the chip strip can render without reaching into
	/// the dialog (which may not exist yet if not opened).
	bool m_binFilterActive = false;
	bool m_binFilterIncomplete = false;
	QStringList m_binFilterBinNames;

	// MARK: - Debounce timers

	/// Debounces the status bar's O(n) byte tally so bursts of
	/// filter changes coalesce into a single walk.
	QTimer *m_statusBarUpdateTimer = nullptr;

	/// Same pattern for the selected-bytes tally; every keystroke
	/// fires onSelectionChanged; the cheap state runs synchronously,
	/// the expensive byte sum waits for this timer.
	QTimer *m_selectionBytesTimer = nullptr;
};
