#pragma once

// Shared OMF1/OMF2 object walks for MdbParser and OmfParser: mob attributes,
// media descriptors, source links and timecode. Schema revision is
// independent of the Bento container version. BentoFile supplies values
// from either an in-memory database or metadata read on demand.

#include "bentofile.h"
#include "avidprecompute.h"
#include "mediametadata.h"

#include <QByteArray>
#include <QByteArrayView>
#include <QHash>
#include <QSet>
#include <QString>
#include <QVector>

namespace OmfObjects
{
	// OMF semantic version, independent of the Bento label's version.
	// OMF1 objects may also be stored in Bento2 (the toolkit's IMA mode).
	enum class Revision
	{
		Unknown,
		Omf1,
		Omf2
	};
	[[nodiscard]] Revision revision(const BentoFile &b);
	[[nodiscard]] QByteArray normalizedMobId(const BentoFile &b, QByteArrayView raw);
	[[nodiscard]] bool isMobClass(const QByteArray &cls);
	// MARK: - Property ids, resolved once per file

	/// Every property the walker reads, resolved by name from the file's
	/// own dictionary. −1 when the file lacks a property: BentoFile reads a
	/// missing (object, property) as empty, so a −1 id simply yields
	/// nothing rather than a guard at every use.
	struct PropertyIds
	{
		Revision revision;
		bool omf2;
		int mobId, usage, name, editRate, attrs, physMedia;
		int attrRefs, attbName, attbKind, attbString, attbObj;
		int binNameUtf8, binName, posixPath, pathUtf8, pathName;
		int essComp, resId, width, height, layout, sampleRate, length, compWidth, bits, channels;
		int tracks, trackComp, sequence, sourceId, tcFlags;

		// OMF-era: the 4CC codec family, the audio header blobs, the
		// timecode start/rate, the media-data MobIDs an essence
		// file keys its data object by, the source-descriptor kind, the
		// UNIX locator's own path property, and the descriptor's locator
		// list (whose MSML names the last known volume).
		int compression, wavdSummary, aifdSummary;
		int tcFrameRate, tcStart;
		int mdatMobId, waveMobId, aifcMobId;
		int mobKind, unxlPath, locator, lastKnownVolumeUtf8, lastKnownVolume;
		int slotRate, nestedSlots, selected, choices, inputSegment;
		int winlPath, maclPath, tiffSummary, rgbaLayout, rgbaStructure;

		explicit PropertyIds(const BentoFile &b);
	};

	/// The first object carrying each raw MobID — the map SCLP source
	/// references are resolved through (a source reference names a mob by
	/// its bytes, not by object handle). OMF-era: keys are the raw bytes of
	/// whichever width the mob was written in (12 or 32), since a SourceID
	/// is written in the same width as the mob it names.
	using ObjectIdByMobId = QHash<QByteArray, quint32>;

	// Mobs referenced by Source Clips in the segment graph; no ancestry hop.
	// Returning all targets lets callers reject ambiguous file/master matches.
	[[nodiscard]] QVector<quint32> referencedMobObjectIds(const BentoFile &b, const PropertyIds &p, quint32 mobObjectId,
														  const ObjectIdByMobId &objectByMob);
	[[nodiscard]] bool readMobEditRate(const BentoFile &b, const PropertyIds &p, quint32 mobObjectId, qint32 &num, qint32 &den);

	// MARK: - Descriptor classes

	/// PCMA / MPGA / WAVE — the audio descriptor classes the MDB writes —
	/// plus, OMF-era, WAVD / AIFD (WAVE and AIFF-C
	/// essence files, whose facts sit in a header blob rather than in
	/// MDAU properties).
	[[nodiscard]] bool isAudioClass(const QByteArray &cls);

	/// Audio plus CDCI / MPGI / RGBA / JPED / TIFD: anything that describes essence
	/// (as opposed to MDES, the import/tape source descriptor).
	[[nodiscard]] bool isMediaClass(const QByteArray &cls);

	/// OMF-era: MACL / WINL / UNXL — the Macintosh, Windows and UNIX
	/// locator classes an attribute or a descriptor may point at. The MDB
	/// path only ever met MACL (measured: WINL 0, UNXL 0 across every
	/// MXF-era MDB on hand); OMF files written on Windows carry WINL.
	[[nodiscard]] bool isLocatorClass(const QByteArray &cls);

	// MARK: - Codec label

	/// OMFI:DIDD:EssenceCompression stores the SMPTE label as an AAF AUID:
	/// the first three GUID fields little-endian (u32, u16, u16) followed by
	/// the eight remaining bytes — and the eight remaining bytes are the
	/// label's FIRST half. So UL = bytes[8..16] + rev(bytes[0..4]) +
	/// rev(bytes[4..6]) + rev(bytes[6..8]). Measured byte-identical to MXF
	/// tag 0x3201 on every file that carries it. Empty unless 16 bytes.
	[[nodiscard]] QByteArray auidToUl(QByteArrayView auid);

	/// Legacy DNxHD essence carries no EssenceCompression in the MDB, only
	/// Avid's numeric resolution id. The DNxHD labels are numbered in step
	/// with it: label byte 13 == id − 1234 (verified on all ten ids in the
	/// corpus: 1235→01 … 1253→13). Ids outside the DNxHD range (2400, 3416,
	/// 557…) are other codecs that DO carry a label, so the guard matters —
	/// empty outside 1235..1489. Id 1244 is the one exception: MC 25.12
	/// registered it under the 0x0D version byte, so that spelling is
	/// returned for it — the 0x0A one names nothing in the app's table.
	[[nodiscard]] QByteArray ulFromResId(quint32 resId);

	// MARK: - OMF-era audio header blobs

	/// OMF-era: what OMFI:WAVD:Summary yields — the RIFF header of the WAVE
	/// file up to (not including) its data. Media Composer writes a `bext`
	/// chunk first, so the reader walks chunks to `fmt ` rather than
	/// trusting a fixed offset. `valid` is false when no `fmt ` chunk fits.
	struct WaveSummary
	{
		quint16 formatTag = 0; ///< 1 = PCM, 3 = IEEE float, 0xFFFE = extensible.
		int channels = 0;
		int sampleRate = 0;
		int bitsPerSample = 0;
		bool valid = false;
	};

	/// OMF-era: OMFI:AIFD:Summary contains a FORM/AIFF or FORM/AIFC header with
	/// its `COMM` chunk (big-endian sizes, an 80-bit extended sample rate,
	/// and a compression type such as "in24" / "NONE" / "sowt").
	struct AifcSummary
	{
		int channels = 0;
		qint64 frames = 0;
		int bitsPerSample = 0;
		int sampleRate = 0;
		MediaRate sampleRateRatio;	   ///< Exact fraction when representable by MediaRate.
		QByteArray sampleRateEncoding; ///< Preserve all ten bytes, including rates beyond rational storage bounds.
		QByteArray compressionType;	   ///< Empty for a plain AIFF `COMM`.
		bool valid = false;
	};

	/// OMF-era: chunk-walk a RIFF/WAVE header blob to its `fmt ` chunk.
	[[nodiscard]] WaveSummary readWaveSummary(QByteArrayView blob);

	/// OMF-era: chunk-walk a FORM/AIFF or FORM/AIFC header blob to `COMM`.
	[[nodiscard]] AifcSummary readAifcSummary(QByteArrayView blob);

	// MARK: - Attribute trees

	/// What a mob's attribute tree yields. Fields fill first-non-empty so
	/// the same struct can be walked from every object that shares a MobID
	/// (Avid may spread attributes across several objects).
	struct Attributes
	{
		QString bin;			 ///< _ORG_BIN → MCBR → OMFI:MCBR:MC:binNameUTF8 (else MC:binName).
		QString sourceFilePath;	 ///< _IMPORTSETTING/_SRCFILE locator path, else _USER/`UNC Path`.
		QString sourceContainer; ///< _USER/Video or Audio — "QTFF" for a QuickTime import.
		QString project;		 ///< OMF-era: _PJ (kind 2) — the project the media was created in.
		QString mediaFilePath;	 ///< OMF-era: _MEDIAFILE locator path (diagnostic; often empty).
		bool isImported = false; ///< An _IMPORTSETTING attribute exists.
		/// OMF-era: set by the caller for a mob written with a 12-byte
		/// omfi:UID (or by the essence-file reader outright). Only then does
		/// _SRCFILE accept a WINL / UNXL target; an MXF-era (32-byte) mob
		/// keeps the MACL-only rule the MDB reader always had, so a
		/// Windows-written MXF-era database reports the same Source File it
		/// did before — the kind-2 `UNC Path` — whatever order its
		/// attributes come in.
		bool omfEra = false;
	};

	/// OMF-era: the path a locator object carries — OMFI:FL:POSIXPathName,
	/// else FL:PathNameUTF8, else FL:PathName, else OMFI:UNXL:PathName (the
	/// UNIX locator's own property). Works for MACL, WINL and UNXL alike.
	[[nodiscard]] QString locatorPath(const BentoFile &b, const PropertyIds &p, quint32 locator);

	/// ATTR → AttrRefs → ATTB[]; nested ATTRs are followed only where a
	/// fact we want lives below them (_IMPORTSETTING, _USER). `seen` guards
	/// the shared nodes Avid writes and must persist across every object
	/// walked into the same `a`. `attrObj` is the handle from
	/// OMFI:CPNT:Attributes; 0 is a no-op.
	void walkAttributes(const BentoFile &b, const PropertyIds &p, quint32 attrObj, Attributes &a, QSet<quint32> &seen);

	/// Media Composer 26.8's precompute display predicate, evaluated on each
	/// logical master separately. No recursive import search or combining
	/// one duplicate's import marker with another duplicate's video tracks.
	/// Unsupported schemas, incomplete evidence and disagreements stay unknown.
	[[nodiscard]] AvidPrecompute::Category precomputeCategory(const BentoFile &b, const PropertyIds &p,
															  const QVector<quint32> &masters);

	// MARK: - Track walk (timecode, source mob)

	/// The first TCCP reachable from `mobObjectId`'s tracks: through SEQU
	/// components, and through SCLP source references into other mobs (the
	/// timecode lives on the tape/import source mob, not the file mob). 0
	/// if none. `seen` prevents cycles; pass a fresh set for each search.
	[[nodiscard]] quint32 findTimecodeComponent(const BentoFile &b, const PropertyIds &p, quint32 mobObjectId,
												const ObjectIdByMobId &objectByMob, QSet<quint32> &seen);

	/// The unique Mob referenced by Source Clips in `mobObjectId`'s segment graph;
	/// 0 when none or several are found. Does not follow further source mobs.
	/// Used to find source-level metadata such as the _PJ project attribute.
	[[nodiscard]] quint32 findUniqueReferencedMobObjectId(const BentoFile &b, const PropertyIds &p, quint32 mobObjectId,
														  const ObjectIdByMobId &objectByMob);

	/// What a TCCP carries. `dropFrame` is OMFI:TCCP:Flags != 0 (the MDB
	/// path's rule); OMF-era: `start` and `frameRate` are OMFI:TCCP:StartTC (in
	/// frames) and OMFI:TCCP:FPS, which an OMF essence file surfaces and an
	/// MXF-era MDB row does not need.
	struct Timecode
	{
		bool found = false;
		bool dropFrame = false;
		qint64 start = -1; ///< Frames; −1 when the property is absent.
		int frameRate = 0;
	};
	[[nodiscard]] Timecode readTimecode(const BentoFile &b, const PropertyIds &p, quint32 timecodeObjectId);

	// MARK: - Descriptor

	/// Fill `e` from the media descriptor `mediaDescriptorObjectId` of the file mob `fileMobObjectId`
	/// the way a header parse would, then hand it to MediaMetadataUtil::finalise so
	/// every derived value comes from the same code as the header path.
	/// Returns false — leaving `e` untouched — when `mediaDescriptorObjectId` is not a media
	/// class. `codecKnown` (optional) reports whether a codec was
	/// established (the stored AUID, one rebuilt from the resolution id,
	/// or — OMF-era, 12-byte file mobs only — a hit in the OmfResolutions
	/// table); the caller decides what "complete" means from that plus the
	/// descriptor class, since MPEG audio has no label here and would
	/// wrongly read as PCM.
	bool readDescriptor(const BentoFile &b, const PropertyIds &p, quint32 fileMobObjectId, quint32 mediaDescriptorObjectId,
						const ObjectIdByMobId &objectByMob, MediaMetadata &e, bool *codecKnown = nullptr);
} // namespace OmfObjects
