#pragma once
#include "opjournal.h"

class OperationRecovery
{
public:
	struct Restorable
	{
		QString journalPath;
		QStringList originals;
		QStringList retainedPaths;
	};
	struct Resumable
	{
		QString journalPath;
		OpKind kind = OpKind::Copy;
		QString dest;
		bool preserve = false;
		bool copiesComplete = false;
		QString started;
		int total = 0;
		int finished = 0;
		QVector<OpItem> remaining;
	};
	struct Summary
	{
		int opsFlagged = 0;
		QStringList notes;
		QVector<Resumable> resumable;
		QVector<Restorable> restorable;
		std::optional<OpJournal::Record> undoCandidate;
		bool hadTrouble() const
		{
			return opsFlagged > 0;
		}
		QString message() const
		{
			return notes.join('\n');
		}
	};
	// Prune and recover under one journal lock, sharing the loaded history.
	static Summary run(const QString &directory = {}, const QVector<VolumeIdentity> &mounted = {});
	static QVector<Resumable> pending(const QString &directory = {});
	static QVector<Restorable> restorable(const QString &directory = {});
	static std::optional<Resumable> resumableFrom(const OpJournal::Record &record);

private:
	static QVector<Restorable> restorableFrom(const QVector<OpJournal::Record> &records);
};
