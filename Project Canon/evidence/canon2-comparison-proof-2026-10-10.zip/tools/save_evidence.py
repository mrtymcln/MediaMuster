from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path('/Users/martymclean/Developer/MediaMuster')
run = Path('/private/tmp/canon2-comparison-20261010')
evidence = root / 'Project Canon/evidence'
summary = json.loads((run / 'summary.json').read_text())
assert summary['status'] == 'passed' and summary['complete']
assert summary['timingPairsPassed'] == 3 and summary['fullProofPassed']

def digest(data):
    return hashlib.sha256(data).hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')

payloads = {}
for path in sorted(run.iterdir()):
    if path.is_file() and path.name != 'save_evidence.py':
        payloads['reports/' + path.name] = path.read_bytes()
for relative in summary['buildReceipt']['sourceSha256']:
    data = (root / relative).read_bytes()
    assert digest(data) == summary['buildReceipt']['sourceSha256'][relative], relative
    payloads['source/' + relative] = data
for relative in ('tests/tst_canon2database.cpp', 'tests/tst_canonscan.cpp',
                 'Project Canon/canon2-comparison-engine-2026-10-10.md',
                 'Project Canon/README.md'):
    payloads['source/' + relative] = (root / relative).read_bytes()

test_paths = sorted((root / 'build-canon2-release/tests').glob('*.result.txt'))
assert len(test_paths) == 43
for path in test_paths:
    payloads['tests/' + path.name] = path.read_bytes()
payloads['tests/ctest.txt'] = Path('/private/tmp/mediamuster-canon2-release-ctest.txt').read_bytes()
payloads['tools/save_evidence.py'] = Path(__file__).read_bytes()

changed = ['CMakeLists.txt', 'tests/CMakeLists.txt', 'tests/tst_canonscan.cpp',
           'src/canon/scanengine.cpp', 'src/canon/scanengine.h',
           'src/canon/scanmodel.h', 'src/canon/sourcearchive.cpp',
           'Project Canon/README.md']
payloads['tracked-changes.patch'] = subprocess.check_output(['git', 'diff', '--', *changed], cwd=root)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip()
fixtures = re.findall(r'QTest::newRow\([^\n]+QStringLiteral\("([^\"]+)"\)',
                      (root / 'tests/tst_canon2database.cpp').read_text())
fixture_hashes = {p: digest((root / 'tests/fixtures' / p).read_bytes()) for p in fixtures}
assert len(fixture_hashes) == 11

primary = root / 'build/MediaMuster.app/Contents/MacOS/MediaMuster'
architectures = subprocess.check_output(['lipo', '-archs', str(primary)], text=True).split()
signature = subprocess.run(['codesign', '--verify', '--deep', '--strict',
                            str(root / 'build/MediaMuster.app')], capture_output=True, text=True)
assert set(architectures) == {'arm64', 'x86_64'} and signature.returncode == 0
receipt = {
    'baseCommit': base, 'branch': branch, 'uncommittedImplementation': True,
    'liveAppEngine': 'Canon', 'comparisonEngine': 'Canon2',
    'primaryAppBuild': {'configuration': 'Debug', 'architectures': architectures,
                        'binarySha256': digest(primary.read_bytes()),
                        'signatureVerified': True},
    'releaseTestSuites': {'passed': 43, 'failed': 0,
                          'canon2DatabaseCases': {'passed': 36, 'skipped': 0},
                          'canon2ScanCases': {'passed': 30, 'skipped': 1},
                          'scanSkipReason': 'Temporary filesystem does not preserve case-distinct file locations'},
    'genuineDatabaseFixtureSha256': fixture_hashes,
    'implementationScope': 'Native PMR/MDB RAM images using verified Canon readers; shared scheduling/selection; no live engine switch',
    'excludedExistingChange': 'Project Canon/database-lookup-optimization-2026-10-10.md',
    'includesOriginalMediaOrDatabaseFiles': False,
}
payloads['verification-receipt.json'] = json_bytes(receipt)
manifest = {name: {'sha256': digest(data), 'bytes': len(data)}
            for name, data in sorted(payloads.items())}
payloads['manifest.json'] = json_bytes(manifest)

zip_path = evidence / 'canon2-comparison-proof-2026-10-10.zip'
assert not zip_path.exists()
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, data in sorted(payloads.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    stored = json.loads(archive.read('manifest.json'))
    for name, record in stored.items():
        data = archive.read(name)
        assert digest(data) == record['sha256'] and len(data) == record['bytes'], name

summary['verificationReceipt'] = receipt
summary['evidenceArchive'] = {'path': str(zip_path.relative_to(root)),
                            'sha256': digest(zip_path.read_bytes()),
                            'bytes': zip_path.stat().st_size,
                            'manifestEntriesVerified': len(manifest)}
summary_path = evidence / 'canon2-comparison-summary-2026-10-10.json'
assert not summary_path.exists()
summary_path.write_bytes(json_bytes(summary))
print(json.dumps({'summary': str(summary_path), 'archive': str(zip_path),
                  'archiveBytes': zip_path.stat().st_size,
                  'manifestEntriesVerified': len(manifest)}))
