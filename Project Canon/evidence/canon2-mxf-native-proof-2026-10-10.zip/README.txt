Canon2 acquired-native-MXF-byte comparison evidence, 10 October 2026.

Live application engine: Canon. Canon2 remains a separate comparison engine.
Both collections use one Release arm64 probe linked to both engines, two full
proof runs and three alternating fresh-process scan-only pairs. Reports retain
source paths/stamps and checksums; CSV output is the existing app export form.
Header-heavy files are whole byte-identical genuine media copies with databases
omitted solely in the test collection. No copied media or binaries are included.
All 47 Release test suites passed; the universal Mac application also built.
Local results do not establish Windows/NEXIS 300,000-file completion or RAM fit.

Read report.md and combined-summary.json for results, proof scope and limitations.
MANIFEST.json lists every other member's exact length and SHA-256.
Source snapshots document uncommitted code matching this comparison stage.
