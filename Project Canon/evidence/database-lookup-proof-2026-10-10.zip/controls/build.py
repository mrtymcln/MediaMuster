from pathlib import Path
import subprocess,json,hashlib,shutil,datetime
p=Path('/private/tmp/canon-projection-controls-20261010'); source=Path('/private/tmp/mediamuster-release-performance-20261009/source'); originalLibrary=Path('/private/tmp/mediamuster-release-performance-20261009/build/libmediamuster_canon.a')
library=p/'libmediamuster_canon-common.a';shutil.copy2(originalLibrary,library)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
common=['clang++','-std=c++17','-O2','-arch','arm64','-DQT_CORE_LIB','-I'+str(source/'src'),'-I'+str(source/'src/canon'),'-isystem','/Users/martymclean/Qt/6.5.3/macos/lib/QtCore.framework/Headers','-iframework','/Users/martymclean/Qt/6.5.3/macos/lib','-isystem','/Users/martymclean/Qt/6.5.3/macos/mkspecs/macx-clang','-isystem','/Users/martymclean/Qt/6.5.3/macos/include']
link=['-F/Users/martymclean/Qt/6.5.3/macos/lib','-framework','QtCore','-framework','Security','-framework','AppKit','-framework','ApplicationServices','-framework','Foundation','-framework','IOKit','-framework','DiskArbitration','-Wl,-rpath,/Users/martymclean/Qt/6.5.3/macos/lib']
records=[]
for mode in ['before','stage1','stage2']:
 cmd=common+[str(p/f'omfprojection-{mode}-instrumented.cpp'),str(p/'probe.cpp'),str(library)]+link+['-o',str(p/f'probe-{mode}')]
 result=subprocess.run(cmd,capture_output=True,text=True);(p/f'build-{mode}.txt').write_text(result.stdout+result.stderr)
 record={'mode':mode,'command':cmd,'exit':result.returncode,'sourceSha256':sha(p/f'omfprojection-{mode}-instrumented.cpp'),'harnessSha256':sha(p/'probe.cpp'),'librarySha256':sha(library)}
 if result.returncode==0:record['binarySha256']=sha(p/f'probe-{mode}')
 records.append(record);(p/'build-receipt.json').write_text(json.dumps({'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commonLibraryOriginalPath':str(originalLibrary),'commonLibraryOriginalSha256':sha(originalLibrary),'commonLibraryFrozenPath':str(library),'headerSourceRoot':str(source),'records':records},indent=2)+'\n')
 print(mode,result.returncode,flush=True)
 if result.returncode:print(result.stderr);break
