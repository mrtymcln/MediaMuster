from pathlib import Path
import re, subprocess, json, hashlib, difflib
root=Path('/Users/martymclean/Developer/MediaMuster')
out=Path('/private/tmp/canon-projection-controls-20261010')
frozen=Path('/private/tmp/canon-database-lookups-20261010')
inputs={'before':subprocess.check_output(['git','show','1a705ea:src/canon/omfprojection.cpp'],cwd=root,text=True),'stage1':(frozen/'omfprojection-stage1.cpp').read_text(),'stage2':(frozen/'omfprojection-stage2.cpp').read_text()}
GLOBAL=r'''
struct DiagnosticCounters {
 qint64 propertiesCalls=0, propertySlots=0, nonemptyLists=0, pointerMatches=0;
 qint64 uniqueCalls=0, uniqueRawCalls=0, uniqueNonempty=0, uniqueRawNonempty=0;
 qint64 componentComputes=0, sourceMobsCalls=0, cacheHits=0, cacheInserts=0;
 QHash<ObjectHandle,qint64> componentsByHandle, sourceMobsByHandle;
} diagnosticCounts;
std::atomic_bool *diagnosticFlag=nullptr;
ObjectHandle diagnosticTarget=0;
qsizetype diagnosticCancelAfter=-1;
bool diagnosticCancelBeforeInsert=false;
QVector<ObjectHandle> diagnosticPartialComponents;
bool diagnosticPartialRecorded=false;
void diagnosticRecordPartial(const QVector<const AvidObject *> &objects) {
 diagnosticPartialRecorded=true; diagnosticPartialComponents.clear();
 for(const auto *object:objects) diagnosticPartialComponents.append(object->handle);
}
void diagnosticAfterVisit(ObjectHandle owner,const QVector<const AvidObject *> &objects,const QVector<ObjectHandle> &pending) {
 if(diagnosticFlag && owner==diagnosticTarget && objects.size()==diagnosticCancelAfter && !pending.isEmpty()) diagnosticFlag->store(true);
}
void diagnosticPreinsert(ObjectHandle owner) {
 if(diagnosticFlag && owner==diagnosticTarget && diagnosticCancelBeforeInsert) diagnosticFlag->store(true);
}
QJsonArray diagnosticArray(const QVector<ObjectHandle> &values) {QJsonArray a;for(auto v:values)a.append(qint64(v));return a;}
QJsonObject diagnosticCounterJson() {
 qint64 repeats=0,maxCalls=0;for(auto n:diagnosticCounts.sourceMobsByHandle){repeats+=n-1;maxCalls=qMax(maxCalls,n);}
 return {{"propertiesCalls",diagnosticCounts.propertiesCalls},{"propertySlotsScanned",diagnosticCounts.propertySlots},
 {"nonemptyTemporaryPropertyLists",diagnosticCounts.nonemptyLists},{"matchedPropertyPointers",diagnosticCounts.pointerMatches},
 {"uniqueCalls",diagnosticCounts.uniqueCalls},{"uniqueRawCalls",diagnosticCounts.uniqueRawCalls},
 {"nonemptyUniqueTemporaryLists",diagnosticCounts.uniqueNonempty},{"nonemptyUniqueRawTemporaryLists",diagnosticCounts.uniqueRawNonempty},
 {"componentComputes",diagnosticCounts.componentComputes},{"componentDistinctHandles",diagnosticCounts.componentsByHandle.size()},
 {"sourceMobsCalls",diagnosticCounts.sourceMobsCalls},{"sourceMobsDistinctHandles",diagnosticCounts.sourceMobsByHandle.size()},
 {"sourceMobsRepeatedCalls",repeats},{"sourceMobsMaxCallsPerHandle",maxCalls},{"sourceMobsCacheHits",diagnosticCounts.cacheHits},{"sourceMobsCacheInserts",diagnosticCounts.cacheInserts}};
}
'''
METHOD=r'''
public:
 QJsonObject diagnosticChoose() const {
  auto handles=m_activeMobs.values();std::sort(handles.begin(),handles.end());
  ObjectHandle partialOwner=0,emptyOwner=0;
  for(const auto handle:handles) {
   const auto *owner=m_objects.value(handle);if(!owner)continue;
   const auto comps=components(*owner);
   const auto oldDiags=m_referenceDiagnostics;
   const auto associations=sourceMobs(*owner);
   if(!partialOwner && comps.size()>=3 && !associations.isEmpty())partialOwner=handle;
   if(!emptyOwner && associations.isEmpty() && oldDiags==m_referenceDiagnostics)emptyOwner=handle;
   if(partialOwner && emptyOwner)break;
  }
  return {{"partialOwner",qint64(partialOwner)},{"emptyOwner",qint64(emptyOwner)}};
 }
 QJsonObject diagnosticLookup(ObjectHandle handle,const QString &mode,std::atomic_bool &flag) const {
  const auto *owner=m_objects.value(handle);if(!owner)return {{"error","owner missing"}};
  diagnosticPartialComponents.clear();diagnosticPartialRecorded=false;
  diagnosticFlag=&flag;diagnosticTarget=handle;diagnosticCancelAfter=mode=="partial"?2:-1;
  diagnosticCancelBeforeInsert=mode=="preinsert";
  const auto computesBefore=diagnosticCounts.componentComputes,hitsBefore=diagnosticCounts.cacheHits;
  const auto first=sourceMobs(*owner);
  const bool afterFirst=DIAGNOSTIC_CONTAINS;
  const auto computesFirst=diagnosticCounts.componentComputes,hitsFirst=diagnosticCounts.cacheHits;
  QVector<ObjectHandle> second;
  if(mode=="empty")second=sourceMobs(*owner);
  if(mode=="cached-cancel") {flag.store(true);second=sourceMobs(*owner);}
  const bool afterSecond=DIAGNOSTIC_CONTAINS;
  diagnosticFlag=nullptr;diagnosticCancelAfter=-1;diagnosticCancelBeforeInsert=false;
  return {{"owner",qint64(handle)},{"mode",mode},{"first",diagnosticArray(first)},{"second",diagnosticArray(second)},
  {"cancelled",flag.load()},{"partialComponents",diagnosticArray(diagnosticPartialComponents)},{"partialRecorded",diagnosticPartialRecorded},
  {"cacheEntryAfterFirst",afterFirst},{"cacheEntryAfterSecond",afterSecond},
  {"firstComponentComputes",computesFirst-computesBefore},{"secondComponentComputes",diagnosticCounts.componentComputes-computesFirst},
  {"firstCacheHits",hitsFirst-hitsBefore},{"secondCacheHits",diagnosticCounts.cacheHits-hitsFirst},
  {"diagnostics",QJsonArray::fromStringList(m_referenceDiagnostics)}};
 }
private:
'''
END=r'''
namespace Canon {
QJsonObject projectionCountReport(){return diagnosticCounterJson();}
void resetProjectionCounters(){diagnosticCounts={};}
QJsonObject projectionControls(const ParsedSource &source) {
 QJsonObject controls;
 const Cancellation selectionCancellation;const auto selected=ObjectProjection(source,selectionCancellation).diagnosticChoose();controls.insert("selected",selected);
 const auto partialOwner=ObjectHandle(selected.value("partialOwner").toInteger());const auto emptyOwner=ObjectHandle(selected.value("emptyOwner").toInteger());
 if(!partialOwner||!emptyOwner){controls.insert("error","genuine fixture did not supply required owners");return controls;}
 for(const auto mode:{"full","partial","preinsert","empty","cached-cancel"}) {
  std::atomic_bool flag{false};const Cancellation cancellation(&flag);ObjectProjection projection(source,cancellation);
  controls.insert(QLatin1String(mode),projection.diagnosticLookup(mode==QLatin1String("empty")?emptyOwner:partialOwner,QLatin1String(mode),flag));
 }
 return controls;
}
QJsonObject propertyChoiceProof(const ParsedSource &source) {
 QCryptographicHash digest(QCryptographicHash::Sha256);qint64 queries=0,nullUnique=0,nullRaw=0;
 auto choice=[&](const AvidObject &object,const QString &query,std::initializer_list<const char*> names) {
  const auto *a=unique(object,names),*b=uniqueRaw(object,names);++queries;nullUnique+=!a;nullRaw+=!b;
  const auto index=[&](Property value)->qint64{return value?value-object.properties.constData():-1;};
  QByteArray line=QByteArray::number(object.handle)+'|'+query.toUtf8()+'|'+QByteArray::number(index(a))+'|'+QByteArray::number(index(b))+'\n';digest.addData(line);
 };
 for(const auto &object:source.objects) {
  QStringList names;for(const auto &property:object.properties)if(!names.contains(property.locator.name))names.append(property.locator.name);
  for(const auto &name:names){const auto latin=name.toLatin1();if(QString::fromLatin1(latin)==name)choice(object,name,{latin.constData()});}
  choice(object,QStringLiteral("OMFI:ObjID|OMFI:OOBJ:ObjClass"),{"OMFI:ObjID","OMFI:OOBJ:ObjClass"});
 }
 return {{"queries",queries},{"nullUnique",nullUnique},{"nullUniqueRaw",nullRaw},{"choiceProvenanceSha256",QString::fromLatin1(digest.result().toHex())}};
}
}
'''
receipts={}
for mode,src in inputs.items():
 original=src
 src='#include <QJsonObject>\n#include <QJsonArray>\n#include <QJsonDocument>\n#include <QCryptographicHash>\n'+src
 src=src.replace('using Property = const RawProperty *;','using Property = const RawProperty *;\n'+GLOBAL,1)
 src,n=re.subn(r'(QVector<Property> properties\([^\n]+\n\s*\{\n\s*QVector<Property> result;)',r'\1\n++diagnosticCounts.propertiesCalls; diagnosticCounts.propertySlots+=object.properties.size();',src,count=1);assert n==1
 src,n=re.subn(r'(return result;\n\s*\}\n\n\s*Property unique\()',r'diagnosticCounts.nonemptyLists+=!result.isEmpty(); diagnosticCounts.pointerMatches+=result.size();\n\1',src,count=1);assert n==1
 for function,counter in [('unique','uniqueCalls'),('uniqueRaw','uniqueRawCalls')]:
  signature='Property '+function+'(const AvidObject &object, std::initializer_list<const char *> names)'
  src,n=re.subn('('+re.escape(signature)+r'\n\s*\{)',lambda m:m.group(1)+'\n++diagnosticCounts.'+counter+';',src,count=1);assert n==1
 if mode=='before':
  for function,counter in [('unique','uniqueNonempty'),('uniqueRaw','uniqueRawNonempty')]:
   start=src.index('Property '+function+'(');end=src.index('\n\t\t}',start)+len('\n\t\t}')
   part=src[start:end].replace('for (const auto *property : properties(object, names))','const auto matches=properties(object,names); diagnosticCounts.'+counter+'+=!matches.isEmpty();\nfor (const auto *property : matches)')
   src=src[:start]+part+src[end:]
 compName='collectComponents' if mode=='stage2' else 'components'
 signature=('ComponentTraversal ' if mode=='stage2' else 'QVector<const AvidObject *> ')+compName+'(const AvidObject &owner) const'
 src,n=re.subn('('+re.escape(signature)+r'\n\s*\{)',lambda m:m.group(1)+'\n++diagnosticCounts.componentComputes; ++diagnosticCounts.componentsByHandle[owner.handle];',src,count=1);assert n==1
 start=src.index(signature); end=src.index('QVector<ObjectHandle> sourceMobs(',start)
 part=src[start:end]
 oldReturn='return {std::move(result), false};' if mode=='stage2' else 'return result;'
 part,n=re.subn(r'(if \(m_cancellation.cancelled\(\)\)\s*)'+re.escape(oldReturn),lambda m:m.group(1)+'{diagnosticRecordPartial(result); '+oldReturn+'}',part,count=1);assert n==1
 needle='pending.append(target->handle);';assert needle in part
 part=part.replace(needle,needle+'\nDIAGNOSTIC_AFTER_TARGET_LOOP',1)
 part,n=re.subn(r'DIAGNOSTIC_AFTER_TARGET_LOOP\s*\}',lambda m:'\n}\ndiagnosticAfterVisit(owner.handle,result,pending);',part,count=1);assert n==1
 # The inserted brace closes the while body too early unless the visit call precedes that close.
 part=part.replace('pending.append(target->handle);\n\n}\ndiagnosticAfterVisit(owner.handle,result,pending);','pending.append(target->handle);\ndiagnosticAfterVisit(owner.handle,result,pending);\n}',1)
 src=src[:start]+part+src[end:]
 signature='QVector<ObjectHandle> sourceMobs(const AvidObject &mob) const'
 src,n=re.subn('('+re.escape(signature)+r'\n\s*\{)',lambda m:m.group(1)+'\n++diagnosticCounts.sourceMobsCalls; ++diagnosticCounts.sourceMobsByHandle[mob.handle];',src,count=1);assert n==1
 if mode=='stage2':
  src=src.replace('return cached.value();','{++diagnosticCounts.cacheHits; return cached.value();}',1)
  src=src.replace('if (traversal.complete && !m_cancellation.cancelled())','diagnosticPreinsert(mob.handle);\nif (traversal.complete && !m_cancellation.cancelled())',1)
  src=src.replace('m_sourceMobsCache.insert(mob.handle, result);','{++diagnosticCounts.cacheInserts; m_sourceMobsCache.insert(mob.handle, result);}',1)
 else:
  start=src.index(signature);end=src.index('void timecode(',start)
  part=src[start:end];pos=part.rindex('return result;');part=part[:pos]+'diagnosticPreinsert(mob.handle);\n'+part[pos:];src=src[:start]+part+src[end:]
 marker='const ParsedSource &m_source;';assert marker in src
 method=METHOD.replace('DIAGNOSTIC_CONTAINS','m_sourceMobsCache.contains(handle)' if mode=='stage2' else 'false')
 src=src.replace(marker,method+'\n'+marker,1)
 src+=END
 (out/f'omfprojection-{mode}-instrumented.cpp').write_text(src)
 (out/f'omfprojection-{mode}-input.cpp').write_text(original)
 (out/f'instrumentation-{mode}.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),src.splitlines(keepends=True),fromfile=f'a/omfprojection-{mode}.cpp',tofile=f'b/omfprojection-{mode}-instrumented.cpp')))
 receipts[mode]={'inputSha256':hashlib.sha256(original.encode()).hexdigest(),'instrumentedSha256':hashlib.sha256(src.encode()).hexdigest()}
# Reuse the existing full-field graph/evidence fingerprint code, removing its timing/storage/main helpers.
proof=Path('/private/tmp/canon-projection-proof-20261010/corpus-proof.cpp').read_text()
start=proof.index('class HashSink');end=proof.index('\nqint64 footprint()')
serial=proof[start:end]
start=proof.index('void projected(');end=proof.index('\nint main(',start)
projected=proof[start:end]
main=r'''
namespace Canon {QJsonObject projectionCountReport();void resetProjectionCounters();QJsonObject projectionControls(const ParsedSource&);QJsonObject propertyChoiceProof(const ParsedSource&);}
int main(int argc,char**argv) {
 QCoreApplication app(argc,argv);if(argc!=2)return 2;
 const QString path=QString::fromLocal8Bit(argv[1]);QFile input(path);if(!input.open(QIODevice::ReadOnly))return 3;
 const CancellationUnused_dummy*unused=nullptr;
 const Canon::Cancellation cancellation;
 const SourceSnapshotRef snapshot=QSharedPointer<SourceSnapshot>::create(SourceSnapshot{MetadataSource::Mdb,path,QFileInfo(path).lastModified(),SourceReadState::NotRead});
 const auto source=Canon::MdbReader{}.read(input,{snapshot,cancellation});
 Canon::resetProjectionCounters();const auto projection=Canon::projectOmf(source,cancellation);const auto counts=Canon::projectionCountReport();
 Fingerprint graphProof;graphProof.graph(source);Fingerprint projectionProof;projected(projectionProof,projection.files);projected(projectionProof,projection.masters);projectionProof.stream<<projection.diagnostics;
 const auto choices=Canon::propertyChoiceProof(source);const auto controls=Canon::projectionControls(source);
 const QJsonObject record{{"path",path},{"sourceOutcome",int(source.outcome)},{"objects",source.objects.size()},{"files",projection.files.size()},{"masters",projection.masters.size()},
 {"graphSha256",QString::fromLatin1(graphProof.result())},{"projectionSha256",QString::fromLatin1(projectionProof.result())},{"counts",counts},{"choices",choices},{"controls",controls}};
 std::puts(QJsonDocument(record).toJson(QJsonDocument::Compact).constData());return controls.contains("error")?4:0;
}
'''.replace(' const CancellationUnused_dummy*unused=nullptr;\n','')
headers='''#include "canon/mdbreader.h"\n#include "canon/projection.h"\n#include <QCoreApplication>\n#include <QCryptographicHash>\n#include <QDataStream>\n#include <QFile>\n#include <QFileInfo>\n#include <QJsonDocument>\n#include <QJsonObject>\n#include <cstdio>\n#include <algorithm>\n'''
(out/'probe.cpp').write_text(headers+serial+'\n'+projected+'\n'+main)
(out/'source-receipt.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
