from pathlib import Path
import subprocess,json,hashlib,os,datetime
p=Path('/private/tmp/canon-projection-controls-20261010');root=Path('/Users/martymclean/Developer/MediaMuster')
fixtures=[root/'tests/fixtures/corpus_headers/msmMMOB.mdb',root/'tests/fixtures/corpus_headers/msmMMOB_round3.mdb']
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def stamp(f):
 s=f.stat();return {'path':str(f),'device':s.st_dev,'inode':s.st_ino,'size':s.st_size,'mtimeNs':s.st_mtime_ns,'sha256':sha(f)}
records=[];errors=[]
for fixture in fixtures:
 for mode in ['before','stage1','stage2']:
  before=stamp(fixture);cmd=[str(p/f'probe-{mode}'),str(fixture)]
  run=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'QT_HASH_SEED':'0'})
  (p/f'{fixture.stem}-{mode}.stdout.jsonl').write_text(run.stdout);(p/f'{fixture.stem}-{mode}.stderr.txt').write_text(run.stderr)
  record={'mode':mode,'fixture':str(fixture),'command':cmd,'exit':run.returncode,'binarySha256':sha(p/f'probe-{mode}'),'fixtureBefore':before,'fixtureAfter':stamp(fixture)}
  if run.returncode:errors.append({'mode':mode,'fixture':str(fixture),'exit':run.returncode,'stderr':run.stderr})
  else:
   try:record['result']=json.loads(run.stdout)
   except Exception as e:errors.append({'mode':mode,'fixture':str(fixture),'parseError':str(e)})
  records.append(record)
  (p/'results.json').write_text(json.dumps({'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'errors':errors},indent=2)+'\n')
  print(mode,fixture.name,run.returncode,flush=True)
checks=[]
for fixture in fixtures:
 group=[r for r in records if r['fixture']==str(fixture) and 'result'in r]
 if len(group)!=3:continue
 results=[r['result']for r in group];base=results[0];final=results[2]
 def check(name,ok):checks.append({'fixture':str(fixture),'check':name,'pass':bool(ok)})
 check('sourceStampsUnchanged',all(r['fixtureBefore']==r['fixtureAfter']==group[0]['fixtureBefore']for r in group))
 for key in ['sourceOutcome','objects','files','masters','graphSha256','projectionSha256','choices']:
  check(key+'Equal',all(r[key]==base[key]for r in results))
 check('selectedOwnersEqual',all(r['controls']['selected']==base['controls']['selected']for r in results))
 for mode in ['full','partial','preinsert','empty','cached-cancel']:
  for key in ['owner','first','second','cancelled','partialComponents','diagnostics'] + (['partialRecorded'] if mode!='cached-cancel' else []):
   check(mode+'_'+key+'Equal',all(r['controls'][mode][key]==base['controls'][mode][key]for r in results))
 partial=final['controls']['partial'];preinsert=final['controls']['preinsert'];empty=final['controls']['empty'];full=final['controls']['full'];cancel=final['controls']['cached-cancel']
 check('partialOrderedPrefixPreserved',partial['partialRecorded'] and len(partial['partialComponents'])==2 and partial['partialComponents']==base['controls']['partial']['partialComponents'])
 check('partialCancelledAndUncached',partial['cancelled'] and not partial['cacheEntryAfterFirst'])
 check('preinsertCancelledFullAnswerUncached',preinsert['cancelled'] and preinsert['first']==full['first'] and not preinsert['cacheEntryAfterFirst'])
 check('finishedEmptyIsCachedAndHit',empty['first']==[] and empty['second']==[] and empty['cacheEntryAfterFirst'] and empty['secondCacheHits']==1 and empty['secondComponentComputes']==0)
 check('cancelEntryAvoidsTraversal',not cancel['partialRecorded'])
 check('cancelPreventsCachedAnswer',cancel['cacheEntryAfterFirst'] and cancel['cancelled'] and cancel['second']==[] and cancel['secondCacheHits']==0 and cancel['secondComponentComputes']==0)
summary={'method':'Read-only diagnostic over two unchanged genuine MDB fixtures. Three temporary projection translation units instrument the fixed before/stage1/stage2 sources; common supporting reader library frozen once. No parser rules or production hooks. Counts captured immediately after ordinary projection, before diagnostic-only helper queries. Full graph/projection/evidence fingerprints, per-object property pointer-index choices and ordered diagnostics compared. Cancellation is deterministically triggered using borrowed external atomic at two specified boundaries; no timing or memory claims.',
'limits':['One genuine fixture family; production full-suite/full-corpus proofs are separate.','Cancellation checkpoints are instrumented solely in temporary copied translation units; this is a control of execution, not a corrupt-file interpretation or new recovery rule.','Mid-traversal case checks acquired ordered components and no cache publication; wall-clock partial scan inventories can naturally differ when execution is faster.','Property choice proof exercises every actual Latin-1 property name singly and the existing ObjID/OOBJ:ObjClass alias group; unchanged graph hash plus identical pointer indices establish selected-property provenance for those queries.','The instrumentation and hash diagnostics add work and are unsuitable for speed/RAM measurements.'],
'controls':{'partial':'External flag is set after exactly two appended objects while work remains pending. Existing next-iteration cancellation returns that ordered component prefix; helper records the returned prefix and cache state.','preinsert':'External flag is set immediately before the cache publication guard; computed associations are still returned but no entry may be stored.','empty':'A genuine active mob with a finished empty association is queried twice; second Stage 2 query must hit cache and perform no component traversal.','cached-cancel':'A complete lookup first populates cache; cancellation is then set before its next request. Cached handles must not be returned.'},
'expectedInstrumentationDifference':'For cached-cancel, baseline/stage1 enter components and record an empty cancelled prefix, while Stage 2 stops at its entry cancellation guard before components. Returned vectors and diagnostics match; this instrumentation-only partialRecorded flag is intentionally excluded from cross-version equality.',
'buildReceipt':str(p/'build-receipt.json'),'sourceReceipt':str(p/'source-receipt.json'),'results':str(p/'results.json'),'checks':checks,'errors':errors,'allPassed':not errors and bool(checks)and all(c['pass']for c in checks),
'files':{str(f):{'bytes':f.stat().st_size,'sha256':sha(f)}for f in [p/'prepare.py',p/'build.py',p/'run.py',p/'probe.cpp',p/'libmediamuster_canon-common.a',*[p/f'omfprojection-{m}-instrumented.cpp'for m in ['before','stage1','stage2']]]}}
summary["countDefinitions"]={'propertiesCalls': 'Temporary QVector instances constructed by properties(), including empty results; direct unique/uniqueRaw loops are not counted here.', 'propertySlotsScanned': 'Sum of object.properties.size() only at properties() entry. After Stage 1 this excludes properties inspected by direct unique/uniqueRaw loops; it is not a total property-visit count across implementations.', 'nonemptyTemporaryPropertyLists': 'All nonempty properties() result vectors; this counts vector instances, not allocator calls or allocation bytes.', 'nonemptyUniqueTemporaryLists': 'Nonempty properties() vectors specifically materialized by unique(). Zero after Stage 1.', 'nonemptyUniqueRawTemporaryLists': 'Nonempty properties() vectors specifically materialized by uniqueRaw(). Zero after Stage 1.', 'componentComputes': 'Actual components traversal computations: components() before/Stage 1, collectComponents() in Stage 2. Wrapper calls that do not compute are excluded.', 'sourceMobsCalls': 'All sourceMobs() requests, including Stage 2 cache hits.', 'sourceMobsCacheHits': 'Requests answered by constFind cache entry after the entry cancellation guard.', 'sourceMobsCacheInserts': 'Finished lookup publications that pass the final cancellation guard; includes finished empty results.'}
(p/'method-and-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'allPassed':summary['allPassed'],'failed':[c for c in checks if not c['pass']],'errors':errors},indent=2))
