// Read-only experiment. Reuse the established semantic fingerprint inventory;
// the app's reader, source model and file-operation code are unchanged.
#define main previousSourceArchiveDiagnosticMain
#include "/Users/martymclean/Developer/MediaMuster/Project Canon/evidence/source-archive-full-proof-2026-10-09.cpp"
#undef main

#include "canon/mdbreader.h"
#include "canon/projection.h"
#include <QBuffer>
#include <array>
#include <limits>
#include <stdexcept>

class CountedInput final : public QIODevice
{
public:
    CountedInput(QIODevice &backend, bool skipSamePosition)
        : m_backend(backend), m_skipSamePosition(skipSamePosition)
    {
        open(QIODevice::ReadOnly | QIODevice::Unbuffered);
    }

    qint64 size() const override { return m_backend.size(); }
    bool seek(qint64 offset) override
    {
        ++seekCalls;
        const bool same = m_backend.pos() == offset;
        samePositionSeeks += same;
        if (!m_skipSamePosition || !same)
        {
            ++forwardedSeeks;
            if (!m_backend.seek(offset))
            {
                setErrorString(m_backend.errorString());
                return false;
            }
        }
        return QIODevice::seek(offset);
    }

    qint64 readCalls = 0, seekCalls = 0, samePositionSeeks = 0;
    qint64 forwardedSeeks = 0, bytesRead = 0, tinyReads = 0;

protected:
    qint64 readData(char *data, qint64 length) override
    {
        ++readCalls;
        tinyReads += length <= 16;
        const qint64 received = m_backend.read(data, length);
        if (received > 0)
            bytesRead += received;
        if (received < 0)
            setErrorString(m_backend.errorString());
        return received;
    }
    qint64 writeData(const char *, qint64) override { return -1; }

private:
    QIODevice &m_backend;
    const bool m_skipSamePosition;
};

void projectedFiles(Fingerprint &proof, const QVector<Canon::ProjectedFile> &files)
{
    proof.stream << qint64(files.size());
    for (const auto &file : files)
    {
        proof.stream << file.fileMobId << file.masterMobIds << file.filenames;
        proof.evidence(file.evidence);
        proof.stream << qint64(file.objects.size());
        for (const auto &object : file.objects)
        {
            proof.snapshot(object.source);
            proof.stream << object.handle;
        }
    }
}

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    if (argc != 3)
        return 1;
    const QString path = QFileInfo(QString::fromLocal8Bit(argv[1])).absoluteFilePath();
    const QByteArray mode(argv[2]);
    if (mode != "file" && mode != "skip" && mode != "buffer")
        return 1;
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
        return 2;
    const QFileInfo before(file);
    const qint64 extent = file.size();
    const auto modified = before.lastModified();
    const auto memoryBefore = footprint();
    const Canon::Cancellation cancellation;
    const SourceSnapshotRef snapshot = QSharedPointer<SourceSnapshot>::create(
        SourceSnapshot{MetadataSource::Mdb, path, modified, SourceReadState::NotRead});

    QByteArray databaseBytes;
    QBuffer memoryInput(&databaseBytes);
    qint64 fetchNanos = 0, fetchCalls = 0;
    QElapsedTimer timer;
    timer.start();
    if (mode == "buffer")
    {
        if (extent < 0 || extent > std::numeric_limits<qsizetype>::max())
            return 3;
        databaseBytes.reserve(qsizetype(extent));
        std::array<char, 65536> chunk;
        while (databaseBytes.size() < extent)
        {
            if (cancellation.cancelled())
                return 4;
            const qint64 wanted = std::min<qint64>(chunk.size(), extent - databaseBytes.size());
            ++fetchCalls;
            const qint64 received = file.read(chunk.data(), wanted);
            if (received <= 0)
                return 5; // Successful-input experiment: do not invent recovery on failed fetch.
            databaseBytes.append(chunk.data(), qsizetype(received));
        }
        if (!memoryInput.open(QIODevice::ReadOnly))
            return 6;
        fetchNanos = timer.nsecsElapsed();
    }
    QIODevice &backend = mode == "buffer" ? static_cast<QIODevice &>(memoryInput)
                                          : static_cast<QIODevice &>(file);
    CountedInput input(backend, mode == "skip");
    timer.restart();
    const auto source = Canon::MdbReader{}.read(input, {snapshot, cancellation});
    const qint64 parseNanos = timer.nsecsElapsed();
    const auto memoryParsed = footprint();
    timer.restart();
    const auto projection = Canon::projectOmf(source, cancellation);
    const qint64 projectNanos = timer.nsecsElapsed();
    const auto memoryProjected = footprint();

    QFileInfo after(file);
    after.refresh();
    const bool unchanged = file.size() == extent && after.size() == extent &&
                           after.lastModified() == modified;
    Fingerprint graphProof;
    graphProof.graph(source);
    Fingerprint projectionProof;
    projectedFiles(projectionProof, projection.files);
    projectedFiles(projectionProof, projection.masters);
    projectionProof.stream << projection.diagnostics;
    const QJsonObject result{
        {"path", path}, {"mode", QString::fromLatin1(mode)}, {"extent", extent},
        {"modified", modified.toString(Qt::ISODateWithMs)}, {"unchanged", unchanged},
        {"outcome", int(source.outcome)}, {"fetchNanos", fetchNanos},
        {"parseNanos", parseNanos}, {"projectNanos", projectNanos},
        {"fetchParseNanos", fetchNanos + parseNanos},
        {"sourceWorkNanos", fetchNanos + parseNanos + projectNanos},
        {"fetchCalls", fetchCalls}, {"bufferBytes", databaseBytes.size()},
        {"memoryBefore", memoryBefore}, {"memoryParsed", memoryParsed},
        {"memoryProjected", memoryProjected},
        {"objects", graphProof.objects}, {"relationships", graphProof.relationships},
        {"properties", graphProof.properties}, {"encodingBytes", graphProof.encodingBytes},
        {"projectedFiles", projection.files.size()}, {"projectedMasters", projection.masters.size()},
        {"readCalls", input.readCalls}, {"seekCalls", input.seekCalls},
        {"samePositionSeeks", input.samePositionSeeks}, {"forwardedSeeks", input.forwardedSeeks},
        {"bytesRead", input.bytesRead}, {"tinyReads", input.tinyReads},
        {"graphSha256", QString::fromLatin1(graphProof.result())},
        {"projectionSha256", QString::fromLatin1(projectionProof.result())}};
    std::puts(QJsonDocument(result).toJson(QJsonDocument::Compact).constData());
    return unchanged && source.outcome == Canon::ParsedSource::Outcome::Complete ? 0 : 7;
}
