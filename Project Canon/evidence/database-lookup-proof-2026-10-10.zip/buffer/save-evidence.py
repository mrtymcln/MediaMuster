from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

repo = Path('/Users/martymclean/Developer/MediaMuster')
destination = repo / 'Project Canon/evidence'
proof = Path('/private/tmp/canon-projection-proof-20261010')
controls = Path('/private/tmp/canon-projection-controls-20261010')
buffer = Path(__file__).resolve().parent

def read(path):
    return json.loads(path.read_text())

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source_hash = sha256(repo / 'src/canon/omfprojection.cpp')
tests = read(proof / 'final-tests-receipt.json')
assert source_hash == tests['projectionSourceSha256']
assert tests['buildExit'] == tests['testExit'] == 0
timings = read(proof / 'scanner-timings/comparison-summary.json')
assert timings['complete'] and timings['allSemanticChecksPass']
for stage in ['stage1', 'stage2']:
    assert read(proof / f'{stage}-comparison.json')['allSemanticChecksPass']
    assert read(proof / f'{stage}-corpus-comparison.json')['allChecksPass']
    assert read(proof / f'{stage}-scanner-comparison.json')['allChecksPass']
control_results = read(controls / 'results.json')
assert not control_results['errors']
buffer_results = read(buffer / 'buffer-comparison.json')
assert buffer_results['sourceStampsStable'] and buffer_results['sourceHashesStable']
assert all(row['matched'] for row in buffer_results['checks'])
app_build = read(buffer / 'primary-app-build-receipt.json')
assert app_build['exitCode'] == 0 and app_build['projectionSourceSha256'] == source_hash

archive_path = destination / 'database-lookup-proof-2026-10-10.zip'
suffixes = {'.json', '.jsonl', '.csv', '.txt', '.py', '.cpp', '.patch', '.diff'}
manifest = []
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for prefix, root in [('proof', proof), ('controls', controls), ('buffer', buffer)]:
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.suffix in suffixes:
                name = f'{prefix}/{path.relative_to(root).as_posix()}'
                archive.write(path, name)
                manifest.append({'name': name, 'bytes': path.stat().st_size, 'sha256': sha256(path)})
    helper = destination / 'source-archive-full-proof-2026-10-09.cpp'
    name = 'shared/' + helper.name
    archive.write(helper, name)
    manifest.append({'name': name, 'bytes': helper.stat().st_size, 'sha256': sha256(helper)})
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in manifest:
        assert hashlib.sha256(archive.read(row['name'])).hexdigest() == row['sha256']

shutil.copyfile(buffer / 'buffer-comparison.json', destination / 'database-buffer-experiment-2026-10-10.json')
controls_receipt = {
    'method': read(controls / 'method-and-checks.json'),
    'results': control_results,
    'build': read(controls / 'build-receipt.json'),
    'source': read(controls / 'source-receipt.json'),
}
(destination / 'database-lookup-controls-2026-10-10.json').write_text(json.dumps(controls_receipt, indent=2) + '\n')

before = read(proof / 'before.json')
receipt = {
    'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': '1a705eaefc191d6efda6cd0485ed953b1c555840',
    'productionChange': 'Only src/canon/omfprojection.cpp: direct unique-property loops and projection-local completed source-mob lookup reuse.',
    'sourceSha256': source_hash,
    'unrelatedPolicyFormattingPreservedAndExcludedFromReleaseSnapshot': True,
    'stageBuild': read(proof / 'stage2-build-receipt.json'),
    'liveCounts': {key: before[key] for key in ['rows', 'sources', 'sourceObjects', 'sourceRelationships', 'sourceProperties', 'originalValueBytes']},
    'stage1': {kind: read(proof / f'stage1-{kind}.json') for kind in ['comparison', 'corpus-comparison', 'scanner-comparison']},
    'stage2': {kind: read(proof / f'stage2-{kind}.json') for kind in ['comparison', 'corpus-comparison', 'scanner-comparison']},
    'timingSummary': timings,
    'testReceipt': tests,
    'primaryAppBuild': app_build,
    'bufferExperiment': {'receipt': 'database-buffer-experiment-2026-10-10.json', 'sha256': sha256(destination / 'database-buffer-experiment-2026-10-10.json'),
                         'semanticChecks': len(buffer_results['checks']), 'allMatched': True,
                         'productionBufferingOrSeekChangeApplied': False},
    'evidenceArchive': {'file': archive_path.name, 'sha256': sha256(archive_path), 'bytes': archive_path.stat().st_size,
                        'retainedTextFiles': len(manifest), 'crcPass': True, 'memberSha256Pass': True},
    'limits': ['Repeated scan timings are warm-cache native arm64 macOS Release results without GUI model population.',
               'No supported RAM-saving claim, Windows/NEXIS throughput claim or 300,000-file qualification.',
               'Both stage correctness proofs compare all represented graph/evidence fields; tested genuine variants do not establish every possible Avid variant.',
               'The old engine remains; no production reader, source schema, metadata selection, scan scheduling or feature flag changes.',
               'Buffer and seek modes remain diagnostic-only; successful-input equality does not qualify failure/partial-read semantics.'],
}
target = destination / 'database-lookup-verification-2026-10-10.json'
target.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(target), 'archive': receipt['evidenceArchive'], 'sourceSha256': source_hash}))
