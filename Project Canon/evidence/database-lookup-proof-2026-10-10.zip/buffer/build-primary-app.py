from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

root = Path('/Users/martymclean/Developer/MediaMuster')
out = Path(__file__).resolve().parent
command = ['cmake', '--build', str(root / 'build'), '--target', 'MediaMuster', '-j', '4']
started = time.perf_counter()
with (out / 'primary-app-build.txt').open('w') as log:
    run = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
binary = root / 'build/MediaMuster.app/Contents/MacOS/MediaMuster'
record = {'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'command': command, 'exitCode': run.returncode, 'seconds': time.perf_counter() - started,
          'buildType': 'Debug', 'architecture': 'arm64;x86_64', 'qtVersion': '6.5.3',
          'projectionSourceSha256': hashlib.sha256((root / 'src/canon/omfprojection.cpp').read_bytes()).hexdigest(),
          'binary': str(binary),
          'binarySha256': hashlib.sha256(binary.read_bytes()).hexdigest() if run.returncode == 0 else None,
          'scope': 'Build the actual primary workspace app; no scan, GUI launch or timing measurement.'}
(out / 'primary-app-build-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(run.returncode)
