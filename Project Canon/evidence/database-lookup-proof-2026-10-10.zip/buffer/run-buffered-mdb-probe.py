#!/usr/bin/env python3
"""Read-only successful-input experiment; no production I/O changes."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "buffered-mdb-probe"
BASELINE = Path("/private/tmp/canon-projection-proof-20261010/before-receipt.json")
DATABASES = sorted(
    [Path(row["path"]) for row in json.loads(BASELINE.read_text())["sourceAndFolderStamps"]
     if row["path"].lower().endswith(".mdb")],
    key=lambda path: path.stat().st_size, reverse=True)


def stamp(path):
    info = path.stat()
    return {"path": str(path), "device": str(info.st_dev), "inode": str(info.st_ino),
            "size": str(info.st_size), "mtimeNs": str(info.st_mtime_ns)}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


original = [stamp(path) for path in DATABASES]
original_hashes = {str(path): sha256(path) for path in DATABASES}
env = dict(os.environ, QT_HASH_SEED="0", QT_QPA_PLATFORM="offscreen")
records = []
for index, modes in enumerate((("file", "skip", "buffer"),
                               ("buffer", "file", "skip"),
                               ("skip", "buffer", "file")), 1):
    for mode in modes:
        path = DATABASES[0]
        command = [str(PROBE), str(path), mode]
        started = time.perf_counter()
        run = subprocess.run(command, env=env, capture_output=True, text=True)
        (ROOT / f"buffer-largest-{index}-{mode}.stderr.txt").write_text(run.stderr)
        if run.returncode:
            raise RuntimeError(f"{command}: exit {run.returncode}: {run.stderr}")
        result = json.loads(run.stdout)
        result.update(trial=index, command=command, processWallSeconds=time.perf_counter() - started)
        (ROOT / f"buffer-largest-{index}-{mode}.json").write_text(json.dumps(result, indent=2) + "\n")
        records.append(result)
        if [stamp(item) for item in DATABASES] != original or not result["unchanged"]:
            raise RuntimeError("Input changed during experiment")
        print(json.dumps({"trial": index, "mode": mode,
                          "sourceWorkMs": result["sourceWorkNanos"] / 1e6}), flush=True)

for index, path in enumerate(DATABASES[1:], 1):
    for mode in ("file", "skip", "buffer"):
        command = [str(PROBE), str(path), mode]
        run = subprocess.run(command, env=env, capture_output=True, text=True)
        (ROOT / f"buffer-other-{index}-{mode}.stderr.txt").write_text(run.stderr)
        if run.returncode:
            raise RuntimeError(f"{command}: exit {run.returncode}: {run.stderr}")
        result = json.loads(run.stdout)
        result.update(trial=0, command=command)
        (ROOT / f"buffer-other-{index}-{mode}.json").write_text(json.dumps(result, indent=2) + "\n")
        records.append(result)
        if [stamp(item) for item in DATABASES] != original or not result["unchanged"]:
            raise RuntimeError("Input changed during experiment")
    print(json.dumps({"correctnessPath": str(path), "modes": 3}), flush=True)

semantic = ("graphSha256", "projectionSha256", "objects", "relationships", "properties",
            "encodingBytes", "projectedFiles", "projectedMasters", "outcome", "extent", "modified")
checks = []
for path in DATABASES:
    group = [row for row in records if row["path"] == str(path)]
    for key in semantic:
        values = [row[key] for row in group]
        checks.append({"path": str(path), "field": key, "matched": all(x == values[0] for x in values)})
if not all(item["matched"] for item in checks):
    raise RuntimeError("Semantic comparison failed")

medians = {}
metrics = ("fetchNanos", "parseNanos", "projectNanos", "fetchParseNanos", "sourceWorkNanos",
           "memoryBefore", "memoryParsed", "memoryProjected", "bufferBytes", "readCalls", "seekCalls",
           "samePositionSeeks", "forwardedSeeks", "fetchCalls", "bytesRead", "tinyReads")
for mode in ("file", "skip", "buffer"):
    group = [row for row in records if row["path"] == str(DATABASES[0]) and row["mode"] == mode]
    medians[mode] = {key: statistics.median(row[key] for row in group) for key in metrics}
final_hashes = {str(path): sha256(path) for path in DATABASES}
if final_hashes != original_hashes or [stamp(path) for path in DATABASES] != original:
    raise RuntimeError("Input content changed during experiment")
final = {
    "recordedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "method": "Six unchanged live MDBs, final Release Canon reader/projection, fresh processes. Three rotating-order trials per mode on the largest; remaining five are correctness-only. Same CountedInput wrapper in all modes. Fetch included in timing; semantic hashing excluded. QT_HASH_SEED=0. No concurrent builds/scans.",
    "limits": ["Local warm-cache macOS experiment, not NEXIS or whole-scan timing.",
               "QIODevice call counts are not physical filesystem or network transactions.",
               "Buffer mode eagerly fetches one whole database with checked 64 KiB chunks; failed/partial input and cancellation behavior are not qualified by these successful-input comparisons.",
               "A production buffer would need original-source freshness checks and preservation of partial evidence/cancellation behavior.",
               "No production buffering or redundant-seek change is applied."],
    "sourceStampsStable": [stamp(path) for path in DATABASES] == original,
    "sourceHashesStable": final_hashes == original_hashes,
    "sources": [dict(row, sha256=original_hashes[row["path"]]) for row in original],
    "probeSha256": sha256(PROBE), "probeSourceSha256": sha256(ROOT / "buffered-mdb-probe.cpp"),
    "checks": checks, "largestDatabaseMedians": medians, "records": records,
}
(ROOT / "buffer-comparison.json").write_text(json.dumps(final, indent=2) + "\n")
print(json.dumps({"semanticChecks": len(checks), "matched": all(x["matched"] for x in checks),
                  "medians": medians}), flush=True)
