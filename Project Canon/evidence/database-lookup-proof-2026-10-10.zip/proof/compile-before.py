import json,subprocess
from pathlib import Path
out=Path('/private/tmp/canon-projection-proof-20261010')
command=json.loads((out/"before-compile-command.json").read_text())
with (out/"before-build.txt").open("w") as log:
 p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
print("compile exit",p.returncode)
raise SystemExit(p.returncode)
