from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

OUT = Path('/private/tmp/canon-projection-proof-20261010')
BUILD = Path('/private/tmp/mediamuster-projection-improvement-20261010/build')
targets = re.findall(r'add_test\(\[=\[(.*?)\]=\]', (BUILD / 'tests/CTestTestfile.cmake').read_text())
assert len(targets) == 41, targets
build_command = ['cmake', '--build', str(BUILD), '--target', *targets, '-j', '4']
test_command = ['ctest', '--test-dir', str(BUILD), '--output-on-failure', '-j', '2']
environment = dict(os.environ, QT_QPA_PLATFORM='offscreen', QT_HASH_SEED='0')
for name in ['MEDIAMUSTER_CANON_REAL_SCAN_ROOTS', 'MEDIAMUSTER_CANON_REAL_SCAN_CSV', 'MEDIAMUSTER_CANON_REAL_SCAN_REPORT']:
    environment.pop(name, None)
with (OUT / 'final-all-tests-build.txt').open('w') as log:
    build = subprocess.run(build_command, stdout=log, stderr=subprocess.STDOUT, env=environment)
if build.returncode:
    raise RuntimeError('Full test build failed')
print(json.dumps({'event': 'all-tests-built', 'targets': len(targets)}), flush=True)
with (OUT / 'final-tests.txt').open('w') as log:
    tests = subprocess.run(test_command, stdout=log, stderr=subprocess.STDOUT, env=environment)
receipt = {'buildCommand': build_command, 'testCommand': test_command,
           'testTargetCount': len(targets), 'buildExit': build.returncode, 'testExit': tests.returncode,
           'qtVersion': '6.5.3', 'buildType': 'Release', 'architecture': 'native arm64',
           'environmentOverrides': {'QT_QPA_PLATFORM': 'offscreen', 'QT_HASH_SEED': '0'},
           'realDriveAuditEnvironmentRemoved': True,
           'librarySha256': hashlib.sha256((BUILD / 'libmediamuster_canon.a').read_bytes()).hexdigest(),
           'scannerSha256': hashlib.sha256((BUILD / 'tests/tst_scanner').read_bytes()).hexdigest(),
           'projectionSourceSha256': hashlib.sha256((BUILD.parent / 'source/src/canon/omfprojection.cpp').read_bytes()).hexdigest()}
(OUT / 'final-tests-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'event': 'all-tests-complete', 'targets': len(targets), 'exit': tests.returncode}), flush=True)
if tests.returncode:
    raise RuntimeError('Full suite failed')
