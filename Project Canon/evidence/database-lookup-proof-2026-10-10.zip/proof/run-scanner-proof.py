from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/Users/martymclean/Developer/MediaMuster')
OUT = Path('/private/tmp/canon-projection-proof-20261010')
BUILD = Path('/private/tmp/mediamuster-projection-improvement-20261010/build')
mode = sys.argv[1]
before_receipt = json.loads((OUT / 'before-receipt.json').read_text())
roots = before_receipt['roots']
report = OUT / f'{mode}-scanner.json'
csv = OUT / f'{mode}-scanner.csv'
binary = BUILD / 'tests/tst_scanner'
if report.exists() or csv.exists():
    raise RuntimeError('Existing scanner evidence must be preserved before retrying')


def stamps():
    values = []
    for expected in before_receipt['sourceAndFolderStamps']:
        stat = os.stat(expected['path'])
        values.append({'path': expected['path'], 'device': str(stat.st_dev),
                       'inode': str(stat.st_ino), 'size': str(stat.st_size),
                       'mtimeNs': str(stat.st_mtime_ns), 'directory': expected['directory']})
    return values


pre = stamps()
if pre != before_receipt['sourceAndFolderStamps']:
    raise RuntimeError('Scanner inputs differ from fresh baseline')
environment = dict(os.environ, QT_HASH_SEED='0', QT_QPA_PLATFORM='offscreen',
                   MEDIAMUSTER_CANON_REAL_SCAN_ROOTS=';'.join(roots),
                   MEDIAMUSTER_CANON_REAL_SCAN_CSV=str(csv),
                   MEDIAMUSTER_CANON_REAL_SCAN_REPORT=str(report))
command = ['/usr/bin/time', '-l', '/usr/bin/arch', '-arm64', str(binary), 'optional_read_only_real_scan']
started = time.perf_counter()
with (OUT / f'{mode}-scanner.stdout.txt').open('w') as stdout, (OUT / f'{mode}-scanner.stderr-time.txt').open('w') as stderr:
    process = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
post = stamps()
receipt = {'mode': mode, 'command': command, 'returncode': process.returncode,
           'processWallSeconds': time.perf_counter() - started, 'inputStampsStable': pre == post,
           'binarySha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
           'qtVersion': '6.5.3', 'architecture': 'native arm64', 'buildType': 'Release',
           'memoryMethod': 'Scanner memory retained with adapter rows before CSV writing and scoped source restoration; no GUI model.',
           'sourceInputStampReference': str(OUT / 'before-receipt.json')}
(OUT / f'{mode}-scanner-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
if process.returncode or pre != post:
    raise RuntimeError(f'Scanner proof failed: exit {process.returncode}, stamp stability {pre == post}')
current = json.loads(report.read_text())
baseline_path = Path('/private/tmp/mdvx-performance-audit/measurements/02-pair1-release.json')
baseline_csv = baseline_path.with_suffix('.csv')
baseline = json.loads(baseline_path.read_text())
source_keys = lambda r: [{k: v for k, v in s.items() if k != 'propertyCapacity'} for s in r['sources']]
checks = {'roots': current['roots'] == baseline['roots'], 'rows': current['rows'] == baseline['rows'],
          'issues': current['issues'] == baseline['issues'],
          'issueCount': current['issueCount'] == baseline['issueCount'],
          'inventoryEveryRow': current['inventory'] == baseline['inventory'],
          'sourcesOrderStatusReadReasonsArchiveMetricsAndGraphCounts': source_keys(current) == source_keys(baseline),
          'csvByteIdentical': csv.read_bytes() == baseline_csv.read_bytes()}
comparison = {'mode': mode, 'baselineReport': str(baseline_path), 'baselineCSV': str(baseline_csv),
              'checks': checks, 'allChecksPass': all(checks.values()),
              'csvSha256': hashlib.sha256(csv.read_bytes()).hexdigest(),
              'rows': current['rows'], 'sources': len(current['sources']),
              'scanMs': current['scanMs'], 'memoryRetained': current['memoryRetained']}
(OUT / f'{mode}-scanner-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
print(json.dumps(comparison, indent=2), flush=True)
if not comparison['allChecksPass']:
    raise RuntimeError('Scanner semantic comparison failed')
