from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/Users/martymclean/Developer/MediaMuster')
OUT = Path('/private/tmp/canon-projection-proof-20261010')
REFERENCE = json.loads((ROOT / 'Project Canon/evidence/source-archive-after-real-scan-2026-10-09.json').read_text())
ROOTS = ['/Users/Shared/AvidMediaComposer', '/Volumes/EDIT']
PATHS = sorted({source['path'] for source in REFERENCE['sources']})
FOLDERS = sorted({str(Path(path).parent) for path in PATHS})


def stamps():
    entries = []
    for path in PATHS + FOLDERS:
        stat = os.stat(path)
        entries.append({'path': path, 'device': str(stat.st_dev), 'inode': str(stat.st_ino),
                        'size': str(stat.st_size), 'mtimeNs': str(stat.st_mtime_ns),
                        'directory': path in FOLDERS})
    return entries


mode = sys.argv[1]
binary = OUT / f'full-proof-{mode}'
report = OUT / f'{mode}.json'
receipt = OUT / f'{mode}-receipt.json'
if report.exists() or receipt.exists():
    raise RuntimeError(f'{mode} proof evidence already exists; preserve it before retrying')
before = stamps()
if mode != 'before':
    original = json.loads((OUT / 'before-receipt.json').read_text())
    if before != original['sourceAndFolderStamps']:
        raise RuntimeError('Input stamps differ from the fresh baseline')
command = ['/usr/bin/time', '-l', '/usr/bin/arch', '-arm64', str(binary), *ROOTS]
start_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
started = time.perf_counter()
with report.open('w') as stdout, (OUT / f'{mode}.stderr-time.txt').open('w') as stderr:
    process = subprocess.run(command, cwd=ROOT, env=dict(os.environ, QT_HASH_SEED='0'),
                             stdout=stdout, stderr=stderr)
elapsed = time.perf_counter() - started
after = stamps()
method = {
    'mode': mode, 'command': command, 'roots': ROOTS, 'startUtc': start_utc,
    'returncode': process.returncode, 'processWallSeconds': elapsed,
    'sourceAndFolderStampsStable': before == after, 'sourceAndFolderStamps': before,
    'binarySha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
    'probeSourceSha256': hashlib.sha256((OUT / 'full-proof.cpp').read_bytes()).hexdigest(),
    'sourceCount': len(PATHS), 'folderCount': len(FOLDERS),
    'qtVersion': '6.5.3', 'architecture': 'native arm64', 'libraryBuild': 'Release -O3 -DNDEBUG',
    'probeBuild': 'C++17 -O2 -DSOURCE_ARCHIVE_PROBE',
    'cacheCondition': 'Warm/uncontrolled local filesystem cache; no purge or cold-cache claim',
    'memoryMethod': 'Retained footprint and peak resident memory taken after scan, before scoped source restoration and fingerprints; no GUI adapter/model in this direct-Canon proof.',
    'timingMethod': 'scanMsInstrumented is direct Canon scan with callback fingerprinting, excludes graph/row semantic hashing and one-source-at-a-time archive restoration. Process wall time includes those inspections.',
    'preservationMethod': 'Every semantic graph/row/evidence/selection field fingerprinted in declared order, hash-map keys sorted; allocation capacities excluded.',
}
receipt.write_text(json.dumps(method, indent=2) + '\n')
if process.returncode:
    raise RuntimeError(f'Proof process failed with {process.returncode}; see stderr-time artifact')
if before != after:
    raise RuntimeError('Inputs changed during proof scan')
result = json.loads(report.read_text())
print(json.dumps({key: result[key] for key in ('rows', 'sources', 'sourceObjects',
    'sourceRelationships', 'sourceProperties', 'originalValueBytes', 'scanMsInstrumented',
    'hashMs', 'footprintRetained', 'peakResidentRetained', 'hashes')}, indent=2), flush=True)
