from pathlib import Path
import json
import sys

OUT = Path('/private/tmp/canon-projection-proof-20261010')
mode = sys.argv[1]
before = json.loads((OUT / 'before.json').read_text())
after = json.loads((OUT / f'{mode}.json').read_text())
excluded = {'scanMsInstrumented', 'hashMs', 'footprintBefore', 'footprintRetained', 'peakResidentRetained'}
checks = {key: before[key] == after[key] for key in before if key not in excluded}
comparison = {'mode': mode, 'checks': checks, 'allSemanticChecksPass': all(checks.values()),
              'beforeScanMsInstrumented': before['scanMsInstrumented'],
              'afterScanMsInstrumented': after['scanMsInstrumented'],
              'beforeFootprintRetained': before['footprintRetained'],
              'afterFootprintRetained': after['footprintRetained'],
              'beforePeakResidentRetained': before['peakResidentRetained'],
              'afterPeakResidentRetained': after['peakResidentRetained'],
              'hashes': after['hashes']}
(OUT / f'{mode}-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
print(json.dumps(comparison, indent=2), flush=True)
if not comparison['allSemanticChecksPass']:
    raise RuntimeError('Full-field semantic comparison failed')
