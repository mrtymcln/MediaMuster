from pathlib import Path
import hashlib
import json
import subprocess
import sys

OUT = Path('/private/tmp/canon-projection-proof-20261010')
mode = sys.argv[1]
baseline = Path('/private/tmp/mediamuster-release-performance-20261009')
current = Path('/private/tmp/mediamuster-projection-improvement-20261010')
tree = baseline if mode == 'before' else current
template = json.loads((OUT / 'before-compile-command.json').read_text())
commands = []
for name in (['corpus-proof'] if mode == 'before' else ['full-proof', 'corpus-proof']):
    command = []
    for argument in template:
        if argument == str(OUT / 'full-proof.cpp'):
            argument = str(OUT / f'{name}.cpp')
        elif argument == str(OUT / 'full-proof-before'):
            argument = str(OUT / f'{name}-{mode}')
        else:
            argument = argument.replace(str(baseline / 'source'), str(tree / 'source'))
            argument = argument.replace(str(baseline / 'build'), str(tree / 'build'))
        command.append(argument)
    with (OUT / f'{mode}-{name}-build.txt').open('w') as log:
        process = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    if process.returncode:
        raise RuntimeError(f'{name} compilation failed: {process.returncode}')
    commands.append({'command': command, 'exit': process.returncode,
                     'binarySha256': hashlib.sha256((OUT / f'{name}-{mode}').read_bytes()).hexdigest(),
                     'probeSourceSha256': hashlib.sha256((OUT / f'{name}.cpp').read_bytes()).hexdigest()})
receipt = {'mode': mode, 'commands': commands,
           'librarySha256': hashlib.sha256((tree / 'build/libmediamuster_canon.a').read_bytes()).hexdigest(),
           'projectionSourceSha256': hashlib.sha256((tree / 'source/src/canon/omfprojection.cpp').read_bytes()).hexdigest(),
           'nativeArchitecture': 'arm64', 'qtVersion': '6.5.3',
           'harnessFlags': '-std=c++17 -O2 -DSOURCE_ARCHIVE_PROBE',
           'libraryBuild': 'Release -O3 -DNDEBUG', 'sourceRoot': str(tree / 'source')}
(OUT / f'{mode}-probe-build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'mode': mode, 'compileExit': 0, 'programs': len(commands)}), flush=True)
