from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path('/private/tmp/canon-projection-proof-20261010')
mode = sys.argv[1]
paths = json.loads((OUT / 'corpus-manifest.json').read_text())
binary = OUT / f'corpus-proof-{mode}'
report_path = OUT / f'{mode}-corpus.json'
if report_path.exists():
    raise RuntimeError('Existing corpus evidence must be preserved before retrying')


def stamps():
    result = []
    for path in paths:
        p = Path(path)
        value = os.stat(path)
        result.append({'path': path, 'device': str(value.st_dev), 'inode': str(value.st_ino),
                       'size': str(value.st_size), 'mtimeNs': str(value.st_mtime_ns),
                       'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    return result


before = stamps()
started = time.perf_counter()
command = ['/usr/bin/arch', '-arm64', str(binary), *paths]
with report_path.open('w') as stdout, (OUT / f'{mode}-corpus.stderr.txt').open('w') as stderr:
    process = subprocess.run(command, env=dict(os.environ, QT_HASH_SEED='0'), stdout=stdout, stderr=stderr)
after = stamps()
receipt = {'mode': mode, 'command': command, 'inputStampsAndHashes': before,
           'inputStampsAndHashesStable': before == after, 'returncode': process.returncode,
           'processWallSeconds': time.perf_counter() - started,
           'binarySha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
           'probeSourceSha256': hashlib.sha256((OUT / 'corpus-proof.cpp').read_bytes()).hexdigest(),
           'method': 'One source expanded/projected/archived/restored at a time; full semantic graph plus every projection/evidence/selection field is hashed; allocation capacities excluded.',
           'scope': 'All 88 committed genuine MDB, OMF, WAV and AIF fixture files, including embedded OMF namespaces.'}
(OUT / f'{mode}-corpus-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
if process.returncode or before != after:
    raise RuntimeError(f'Corpus proof failed: process exit {process.returncode}, input stability {before == after}')
result = json.loads(report_path.read_text())
compared_fields = ['path', 'outcome', 'objects', 'relationships', 'properties', 'encodingBytes',
                   'files', 'masters', 'graphSha256', 'projectionSha256', 'archiveGraphSha256', 'archivePreserved']
if mode != 'before':
    original_receipt = json.loads((OUT / 'before-corpus-receipt.json').read_text())
    if before != original_receipt['inputStampsAndHashes']:
        raise RuntimeError('Corpus inputs differ from baseline')
    baseline = json.loads((OUT / 'before-corpus.json').read_text())
    differences = []
    for a, b in zip(baseline, result):
        for key in compared_fields:
            if a[key] != b[key]:
                differences.append({'path': a['path'], 'field': key, 'before': a[key], 'after': b[key]})
    comparison = {'mode': mode, 'fixtureCount': len(result), 'sameFixtureCount': len(baseline) == len(result),
                  'comparedFields': compared_fields, 'differences': differences,
                  'allChecksPass': len(baseline) == len(result) and not differences}
    (OUT / f'{mode}-corpus-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    if not comparison['allChecksPass']:
        raise RuntimeError('Corpus semantic comparison failed: ' + json.dumps(differences[:5]))
print(json.dumps({'mode': mode, 'fixtures': len(result),
                  'allArchivesPreserved': all(r['archivePreserved'] for r in result),
                  'allComparisonChecksPass': mode == 'before' or comparison['allChecksPass']}), flush=True)
