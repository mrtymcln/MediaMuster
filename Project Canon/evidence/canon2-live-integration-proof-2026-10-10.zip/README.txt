Canon2 live integration proof, 10 October 2026.
The app now selects Canon2 through its real MediaScanner adapter.
Before/after live adapters read the same local/EDIT files; CSV output, inventory,
issues, source outcomes/read reasons and restored graph counts match.
All 47 Release regression suites pass; the universal signed Mac app built.
Single audit timings/memory counters are observations, not a benchmark.
Windows/NEXIS and the approximately 300,000-file workload remain unqualified.
Previous full recursive graph/evidence/native-byte proof is saved separately.
MANIFEST.json records every other member's length and SHA-256 checksum.
No media payloads or executable binaries are included.
