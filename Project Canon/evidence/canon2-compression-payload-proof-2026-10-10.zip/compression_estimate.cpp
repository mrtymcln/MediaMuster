// Read-only payload experiment. No application storage or scan policy changes.
// Reported bytes exclude retained Qt objects, receipts and allocation overhead.
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDataStream>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <algorithm>
#include <limits>
#include <stdexcept>

namespace
{
void require(bool condition, const char *message)
{
    if (!condition)
        throw std::runtime_error(message);
}

qint64 compressedSize(const QByteArray &bytes, int level, qsizetype blockSize)
{
    qint64 total = 0;
    for (qsizetype offset = 0; offset < bytes.size(); offset += blockSize)
    {
        const QByteArray block = bytes.sliced(offset, std::min(blockSize, bytes.size() - offset));
        const QByteArray compressed = qCompress(block, level);
        require(!compressed.isEmpty(), "Compression failed");
        require(qUncompress(compressed) == block, "Compression round-trip changed bytes");
        total += compressed.size();
    }
    return total;
}
}

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    try
    {
        require(app.arguments().size() == 2, "Pass one saved full comparison report");
        QFile reportFile(app.arguments().at(1));
        require(reportFile.open(QIODevice::ReadOnly), "Cannot read saved report");
        QJsonParseError parseError;
        const auto document = QJsonDocument::fromJson(reportFile.readAll(), &parseError);
        require(parseError.error == QJsonParseError::NoError, "Malformed report JSON");
        const auto report = document.object();
        require(report.value("verificationPassed").toBool(), "Input comparison proof did not pass");
        QJsonArray measurements;
        for (const auto &value : report.value("sourceDigests").toArray())
        {
            const auto source = value.toObject();
            const bool database = source.contains("databaseImage");
            if (!database && !source.contains("mxfImage"))
                continue;
            const QString path = source.value("path").toString();
            QFile input(path);
            require(input.open(QIODevice::ReadOnly), "Cannot read original source");
            QByteArray packed;
            qint64 payloadBytes = 0;
            if (database)
            {
                const auto receipt = source.value("databaseImage").toObject();
                packed = input.readAll();
                payloadBytes = packed.size();
                require(payloadBytes == receipt.value("capturedBytes").toInteger(), "Database extent changed");
                require(QCryptographicHash::hash(packed, QCryptographicHash::Sha256).toHex() ==
                        receipt.value("imageSha256").toString().toLatin1(), "Database bytes changed");
            }
            else
            {
                const auto receipt = source.value("mxfImage").toObject();
                require(input.size() == receipt.value("physicalSize").toInteger(), "MXF extent changed");
                const auto ranges = receipt.value("ranges").toArray();
                // Include the original extent and every offset/length, keeping gaps
                // explicit. This measurement container is not a production format.
                QDataStream stream(&packed, QIODevice::WriteOnly);
                stream.setVersion(QDataStream::Qt_6_0);
                stream << input.size() << qint64(ranges.size());
                for (const auto &rangeValue : ranges)
                {
                    const auto range = rangeValue.toObject();
                    const qint64 offset = range.value("offset").toInteger();
                    const qint64 length = range.value("bytes").toInteger();
                    require(length > 0 && length <= std::numeric_limits<int>::max(), "Unexpected range extent");
                    require(input.seek(offset), "Cannot seek to acquired MXF range");
                    const QByteArray bytes = input.read(length);
                    require(bytes.size() == length, "Short acquired range read");
                    require(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex() ==
                            range.value("imageSha256").toString().toLatin1(), "Acquired MXF range changed");
                    stream << offset << length;
                    require(stream.writeRawData(bytes.constData(), int(length)) == length, "Cannot frame acquired range");
                    payloadBytes += length;
                }
                require(payloadBytes == receipt.value("capturedBytes").toInteger(), "MXF byte count changed");
                require(stream.status() == QDataStream::Ok, "Cannot write measurement framing");
            }
            const qsizetype wholeSize = packed.size();
            require(wholeSize > 0, "Unexpected empty image");
            measurements.append(QJsonObject{
                {"path", path}, {"kind", database ? "Database" : "Mxf"},
                {"databaseHint", database ? source.value("hint") : QJsonValue()},
                {"originalPayloadBytes", payloadBytes}, {"framedBytes", qint64(wholeSize)},
                {"wholeLevel1Bytes", compressedSize(packed, 1, wholeSize)},
                {"wholeLevel6Bytes", compressedSize(packed, 6, wholeSize)},
                {"blocks64KiBLevel1Bytes", compressedSize(packed, 1, 65536)},
                {"blocks64KiBLevel6Bytes", compressedSize(packed, 6, 65536)},
                {"allRoundTripsExact", true}});
        }
        QFile output;
        require(output.open(stdout, QIODevice::WriteOnly), "Cannot open output");
        const auto result = QJsonDocument(QJsonObject{
            {"qtVersion", qVersion()}, {"inputReport", app.arguments().at(1)},
            {"sourceCount", measurements.size()}, {"images", measurements},
            {"scope", "Exact previously acquired native source payloads; MXF offset/length map and physical extent included. All qUncompress round-trips verified. Not whole-app RAM."}}).toJson();
        require(output.write(result) == result.size(), "Cannot write result");
        return 0;
    }
    catch (const std::exception &error)
    {
        qCritical("%s", error.what());
        return 1;
    }
}
